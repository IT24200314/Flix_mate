#!/usr/bin/env python3
"""
Test script to verify booking functionality
"""
import requests
import json
import time

# Base URL for the API
BASE_URL = "http://localhost:8080"

def test_booking_endpoints():
    """Test the booking endpoints to ensure they work correctly"""
    
    print("=== Testing Booking Functionality ===")
    
    # Test 1: Get all bookings
    print("\n1. Testing GET /api/bookings")
    try:
        response = requests.get(f"{BASE_URL}/api/bookings")
        print(f"Status Code: {response.status_code}")
        if response.status_code == 200:
            bookings = response.json()
            print(f"Number of bookings retrieved: {len(bookings)}")
            if bookings:
                print("Sample booking:")
                print(json.dumps(bookings[0], indent=2))
        else:
            print(f"Error: {response.text}")
    except Exception as e:
        print(f"Error testing bookings endpoint: {e}")
    
    # Test 2: Get bookings for a specific user
    print("\n2. Testing GET /api/bookings/user/john@example.com")
    try:
        response = requests.get(f"{BASE_URL}/api/bookings/user/john@example.com")
        print(f"Status Code: {response.status_code}")
        if response.status_code == 200:
            user_bookings = response.json()
            print(f"Number of bookings for john@example.com: {len(user_bookings)}")
            if user_bookings:
                print("Sample user booking:")
                print(json.dumps(user_bookings[0], indent=2))
        else:
            print(f"Error: {response.text}")
    except Exception as e:
        print(f"Error testing user bookings endpoint: {e}")
    
    # Test 3: Get available seats for a showtime
    print("\n3. Testing GET /api/bookings/available-seats/1")
    try:
        response = requests.get(f"{BASE_URL}/api/bookings/available-seats/1")
        print(f"Status Code: {response.status_code}")
        if response.status_code == 200:
            available_seats = response.json()
            print(f"Number of available seats for showtime 1: {len(available_seats)}")
            if available_seats:
                print("Sample available seat:")
                print(json.dumps(available_seats[0], indent=2))
        else:
            print(f"Error: {response.text}")
    except Exception as e:
        print(f"Error testing available seats endpoint: {e}")
    
    # Test 4: Get booking history for a user
    print("\n4. Testing GET /api/bookings/history/john@example.com")
    try:
        response = requests.get(f"{BASE_URL}/api/bookings/history/john@example.com")
        print(f"Status Code: {response.status_code}")
        if response.status_code == 200:
            booking_history = response.json()
            print(f"Number of bookings in history for john@example.com: {len(booking_history)}")
            if booking_history:
                print("Sample booking history entry:")
                print(json.dumps(booking_history[0], indent=2))
        else:
            print(f"Error: {response.text}")
    except Exception as e:
        print(f"Error testing booking history endpoint: {e}")
    
    print("\n=== Booking Functionality Test Complete ===")

if __name__ == "__main__":
    # Wait a bit for the application to start
    print("Waiting for application to start...")
    time.sleep(5)
    
    test_booking_endpoints()
