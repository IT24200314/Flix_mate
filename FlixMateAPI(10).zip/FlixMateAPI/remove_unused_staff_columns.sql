-- Remove unused columns from staff table
-- This script removes columns that are not being used in the application

PRINT 'Starting removal of unused staff columns...'

-- Check if columns exist before dropping them
IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'staff' AND COLUMN_NAME = 'emergency_contact_name')
BEGIN
    ALTER TABLE staff DROP COLUMN emergency_contact_name;
    PRINT 'Dropped emergency_contact_name column';
END
ELSE
BEGIN
    PRINT 'emergency_contact_name column does not exist';
END

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'staff' AND COLUMN_NAME = 'emergency_contact_phone')
BEGIN
    ALTER TABLE staff DROP COLUMN emergency_contact_phone;
    PRINT 'Dropped emergency_contact_phone column';
END
ELSE
BEGIN
    PRINT 'emergency_contact_phone column does not exist';
END

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'staff' AND COLUMN_NAME = 'date_of_birth')
BEGIN
    ALTER TABLE staff DROP COLUMN date_of_birth;
    PRINT 'Dropped date_of_birth column';
END
ELSE
BEGIN
    PRINT 'date_of_birth column does not exist';
END

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'staff' AND COLUMN_NAME = 'national_id')
BEGIN
    ALTER TABLE staff DROP COLUMN national_id;
    PRINT 'Dropped national_id column';
END
ELSE
BEGIN
    PRINT 'national_id column does not exist';
END

PRINT 'Unused columns removal completed successfully!';
PRINT 'Remaining columns in staff table:';
SELECT COLUMN_NAME, DATA_TYPE, IS_NULLABLE 
FROM INFORMATION_SCHEMA.COLUMNS 
WHERE TABLE_NAME = 'staff' 
ORDER BY ORDINAL_POSITION;
