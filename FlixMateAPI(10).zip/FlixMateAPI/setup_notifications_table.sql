-- Create notifications table
CREATE TABLE IF NOT EXISTS notifications (
    notification_id BIGINT AUTO_INCREMENT PRIMARY KEY,
    type VARCHAR(50) NOT NULL,
    title VARCHAR(255) NOT NULL,
    message TEXT NOT NULL,
    is_read BOOLEAN NOT NULL DEFAULT FALSE,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    read_at TIMESTAMP NULL
);

-- Create index for better performance
CREATE INDEX IF NOT EXISTS idx_notifications_created_at ON notifications(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_notifications_read ON notifications(is_read);

-- Insert some sample notifications for testing
INSERT INTO notifications (type, title, message, is_read, created_at) VALUES
('MOVIE_ADDED', 'New Movie Added', 'A new movie "The Matrix" has been added to the system.', false, NOW()),
('SHOWTIME_ADDED', 'New Showtime Added', 'A new showtime for "The Matrix" has been scheduled for 2024-01-15 19:00.', false, NOW()),
('STAFF_ADDED', 'New Staff Member Added', 'A new staff member "John Doe" has been added to the system.', false, NOW()),
('STAFF_SCHEDULE_ADDED', 'New Staff Schedule Added', 'A new schedule has been assigned to staff member "John Doe" for Monday 9:00 AM.', false, NOW()),
('ADMIN_ADDED', 'New Admin Added', 'A new admin user "admin2@example.com" has been added to the system.', false, NOW());
