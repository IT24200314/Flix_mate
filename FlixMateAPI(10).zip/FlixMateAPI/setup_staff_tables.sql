-- Setup Staff Management Tables
-- This script creates the necessary tables for staff management

USE FLIXMATE_2_0;
GO

-- Create staff table if it doesn't exist
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[staff]') AND type in (N'U'))
BEGIN
    CREATE TABLE [dbo].[staff] (
        [id] BIGINT IDENTITY(1,1) PRIMARY KEY,
        [first_name] NVARCHAR(50) NOT NULL,
        [last_name] NVARCHAR(50) NOT NULL,
        [email] NVARCHAR(100) NOT NULL UNIQUE,
        [phone] NVARCHAR(20),
        [position] NVARCHAR(50) NOT NULL,
        [assigned_hall_id] INT,
        [address] NVARCHAR(500),
        [status] NVARCHAR(20) NOT NULL DEFAULT 'Active',
        [hire_date] DATETIME2 DEFAULT GETDATE(),
        [salary] DECIMAL(10,2),
        [emergency_contact_name] NVARCHAR(100),
        [emergency_contact_phone] NVARCHAR(20),
        [date_of_birth] DATE,
        [national_id] NVARCHAR(20),
        [created_at] DATETIME2 DEFAULT GETDATE(),
        [updated_at] DATETIME2 DEFAULT GETDATE()
    );
    PRINT 'Staff table created successfully.';
END
ELSE
BEGIN
    PRINT 'Staff table already exists.';
END

-- Create staff_schedules table if it doesn't exist
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[staff_schedules]') AND type in (N'U'))
BEGIN
    CREATE TABLE [dbo].[staff_schedules] (
        [schedule_id] BIGINT IDENTITY(1,1) PRIMARY KEY,
        [staff_id] BIGINT NOT NULL,
        [staff_name] NVARCHAR(100) NOT NULL,
        [start_time] DATETIME2 NOT NULL,
        [end_time] DATETIME2 NOT NULL,
        [hall_id] INT NOT NULL,
        [shift_type] NVARCHAR(20) DEFAULT 'Regular',
        [status] NVARCHAR(20) DEFAULT 'Scheduled',
        [notes] NVARCHAR(500),
        [created_at] DATETIME2 DEFAULT GETDATE(),
        [updated_at] DATETIME2 DEFAULT GETDATE()
    );
    PRINT 'Staff_schedules table created successfully.';
END
ELSE
BEGIN
    PRINT 'Staff_schedules table already exists.';
END

-- Create cinema_halls table if it doesn't exist
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[cinema_halls]') AND type in (N'U'))
BEGIN
    CREATE TABLE [dbo].[cinema_halls] (
        [hall_id] INT IDENTITY(1,1) PRIMARY KEY,
        [name] NVARCHAR(100) NOT NULL,
        [location] NVARCHAR(255),
        [capacity] INT NOT NULL
    );
    
    -- Insert sample cinema halls
    INSERT INTO [dbo].[cinema_halls] ([name], [location], [capacity]) VALUES 
    ('Hall A', 'Ground Floor', 100),
    ('Hall B', 'First Floor', 120),
    ('Hall C', 'Second Floor', 80),
    ('Hall D', 'Ground Floor', 150);
    
    PRINT 'Cinema_halls table created successfully with sample data.';
END
ELSE
BEGIN
    PRINT 'Cinema_halls table already exists.';
END

-- Add foreign key constraints if they don't exist
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_staff_schedules_staff')
BEGIN
    BEGIN TRY
        ALTER TABLE [dbo].[staff_schedules] ADD CONSTRAINT FK_staff_schedules_staff 
        FOREIGN KEY ([staff_id]) REFERENCES [dbo].[staff]([id]) ON DELETE CASCADE;
        PRINT 'Added foreign key constraint FK_staff_schedules_staff.';
    END TRY
    BEGIN CATCH
        PRINT 'Warning: Could not add foreign key constraint FK_staff_schedules_staff.';
    END CATCH
END

-- Insert sample staff data if table is empty
IF NOT EXISTS (SELECT 1 FROM [dbo].[staff])
BEGIN
    INSERT INTO [dbo].[staff] (
        [first_name], [last_name], [email], [phone], [position], 
        [assigned_hall_id], [address], [status], [salary]
    ) VALUES
    ('John', 'Smith', 'john.smith@flixmate.com', '+1-555-0123', 'Manager', 1, '123 Main St', 'Active', 5000.00),
    ('Sarah', 'Johnson', 'sarah.johnson@flixmate.com', '+1-555-0124', 'Ticket Seller', 2, '456 Oak Ave', 'Active', 3000.00),
    ('Mike', 'Wilson', 'mike.wilson@flixmate.com', '+1-555-0125', 'Usher', 3, '789 Pine St', 'Active', 2500.00);
    
    PRINT 'Sample staff data inserted successfully.';
END

-- Insert sample schedule data if table is empty
IF NOT EXISTS (SELECT 1 FROM [dbo].[staff_schedules])
BEGIN
    INSERT INTO [dbo].[staff_schedules] (
        [staff_id], [staff_name], [start_time], [end_time], [hall_id], [shift_type], [status]
    ) VALUES
    (1, 'John Smith', '2024-01-15T09:00:00', '2024-01-15T17:00:00', 1, 'Regular', 'Scheduled'),
    (2, 'Sarah Johnson', '2024-01-15T10:00:00', '2024-01-15T18:00:00', 2, 'Regular', 'Scheduled'),
    (3, 'Mike Wilson', '2024-01-15T14:00:00', '2024-01-15T22:00:00', 3, 'Regular', 'Scheduled');
    
    PRINT 'Sample schedule data inserted successfully.';
END

PRINT 'Staff management tables setup completed successfully!';
