-- Fix Data Type Mismatch Between JPA Entities and Database Schema
-- This script updates the database column types to match the JPA entity definitions

USE FLIXMATE_2_0;

-- Fix discount_codes table column types
-- Change DECIMAL columns to FLOAT to match JPA Double type
ALTER TABLE [dbo].[discount_codes] 
ALTER COLUMN [discount_value] FLOAT(53);

ALTER TABLE [dbo].[discount_codes] 
ALTER COLUMN [min_purchase_amount] FLOAT(53);

ALTER TABLE [dbo].[discount_codes] 
ALTER COLUMN [max_discount_amount] FLOAT(53);

-- Fix other tables that might have similar issues
-- Check and fix bookings table
ALTER TABLE [dbo].[bookings] 
ALTER COLUMN [total_amount] FLOAT(53);

-- Check and fix payments table  
ALTER TABLE [dbo].[payments] 
ALTER COLUMN [amount] FLOAT(53);

ALTER TABLE [dbo].[payments] 
ALTER COLUMN [refund_amount] FLOAT(53);

-- Check and fix promotional_banners table
ALTER TABLE [dbo].[promotional_banners] 
ALTER COLUMN [discount_percentage] FLOAT(53);

PRINT 'Data type mismatches fixed successfully!';
PRINT 'All DECIMAL columns have been converted to FLOAT(53) to match JPA Double types.';
