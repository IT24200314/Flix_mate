-- Check Schedule Times
-- This script verifies that schedule times are stored correctly

USE FLIXMATE_2_0;
GO

-- Check the latest schedules to verify time formatting
SELECT 
    schedule_id,
    staff_name,
    start_time,
    end_time,
    hall_id,
    shift_type,
    status,
    notes,
    created_at
FROM staff_schedules
ORDER BY created_at DESC;

PRINT 'Schedule times verification complete.';
