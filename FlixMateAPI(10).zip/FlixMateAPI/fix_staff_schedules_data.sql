-- Fix Staff Schedules Data
-- This script updates the existing staff_schedules table to properly link with staff table

PRINT 'Fixing Staff Schedules Data...';

-- ========================================
-- 1. UPDATE STAFF_ID VALUES BASED ON STAFF_NAME
-- ========================================

-- Update staff_id for John Doe (ID: 1)
UPDATE [dbo].[staff_schedules] 
SET [staff_id] = 1 
WHERE [staff_name] = 'John Doe' AND [staff_id] IS NULL;

-- Update staff_id for Jane Smith (ID: 2)  
UPDATE [dbo].[staff_schedules] 
SET [staff_id] = 2 
WHERE [staff_name] = 'Jane Smith' AND [staff_id] IS NULL;

-- Update staff_id for Mike Johnson (ID: 3)
UPDATE [dbo].[staff_schedules] 
SET [staff_id] = 3 
WHERE [staff_name] = 'Mike Johnson' AND [staff_id] IS NULL;

PRINT 'Updated staff_id values for existing schedules.';

-- ========================================
-- 2. ADD MISSING COLUMNS IF NEEDED
-- ========================================

-- Add shift_type column if it doesn't exist
IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID('staff_schedules') AND name = 'shift_type')
BEGIN
    ALTER TABLE [dbo].[staff_schedules] ADD [shift_type] NVARCHAR(20) DEFAULT 'Regular';
    PRINT 'Added shift_type column.';
END

-- Add status column if it doesn't exist
IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID('staff_schedules') AND name = 'status')
BEGIN
    ALTER TABLE [dbo].[staff_schedules] ADD [status] NVARCHAR(20) DEFAULT 'Scheduled';
    PRINT 'Added status column.';
END

-- Add notes column if it doesn't exist
IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID('staff_schedules') AND name = 'notes')
BEGIN
    ALTER TABLE [dbo].[staff_schedules] ADD [notes] NVARCHAR(500);
    PRINT 'Added notes column.';
END

-- Add created_at column if it doesn't exist
IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID('staff_schedules') AND name = 'created_at')
BEGIN
    ALTER TABLE [dbo].[staff_schedules] ADD [created_at] DATETIME2 DEFAULT GETDATE();
    PRINT 'Added created_at column.';
END

-- Add updated_at column if it doesn't exist
IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID('staff_schedules') AND name = 'updated_at')
BEGIN
    ALTER TABLE [dbo].[staff_schedules] ADD [updated_at] DATETIME2 DEFAULT GETDATE();
    PRINT 'Added updated_at column.';
END

-- ========================================
-- 3. UPDATE NULL VALUES WITH DEFAULT DATA
-- ========================================

-- Update NULL shift_type values
UPDATE [dbo].[staff_schedules] 
SET [shift_type] = 'Evening' 
WHERE [shift_type] IS NULL;

-- Update NULL status values
UPDATE [dbo].[staff_schedules] 
SET [status] = 'Scheduled' 
WHERE [status] IS NULL;

-- Update NULL notes values with descriptive text
UPDATE [dbo].[staff_schedules] 
SET [notes] = 'Staff schedule for ' + [staff_name] + ' in Hall ' + CAST([hall_id] AS NVARCHAR(10))
WHERE [notes] IS NULL;

-- Update NULL created_at values
UPDATE [dbo].[staff_schedules] 
SET [created_at] = GETDATE() 
WHERE [created_at] IS NULL;

-- Update NULL updated_at values
UPDATE [dbo].[staff_schedules] 
SET [updated_at] = GETDATE() 
WHERE [updated_at] IS NULL;

PRINT 'Updated NULL values with default data.';

-- ========================================
-- 4. ADD MORE SAMPLE SCHEDULES FOR OTHER STAFF
-- ========================================

-- Add schedules for Sarah Wilson (ID: 4)
IF NOT EXISTS (SELECT 1 FROM [dbo].[staff_schedules] WHERE [staff_id] = 4)
BEGIN
    INSERT INTO [dbo].[staff_schedules] ([staff_id], [staff_name], [start_time], [end_time], [hall_id], [shift_type], [status], [notes]) VALUES
    (4, 'Sarah Wilson', '2025-01-28 12:00:00', '2025-01-28 20:00:00', 2, 'Day', 'Scheduled', 'Usher shift - Hall B');
    PRINT 'Added schedule for Sarah Wilson.';
END

-- Add schedules for David Brown (ID: 5)
IF NOT EXISTS (SELECT 1 FROM [dbo].[staff_schedules] WHERE [staff_id] = 5)
BEGIN
    INSERT INTO [dbo].[staff_schedules] ([staff_id], [staff_name], [start_time], [end_time], [hall_id], [shift_type], [status], [notes]) VALUES
    (5, 'David Brown', '2025-01-28 08:00:00', '2025-01-28 16:00:00', 3, 'Day', 'Scheduled', 'Security shift - Hall C');
    PRINT 'Added schedule for David Brown.';
END

-- Add schedules for kamal Perera (ID: 6)
IF NOT EXISTS (SELECT 1 FROM [dbo].[staff_schedules] WHERE [staff_id] = 6)
BEGIN
    INSERT INTO [dbo].[staff_schedules] ([staff_id], [staff_name], [start_time], [end_time], [hall_id], [shift_type], [status], [notes]) VALUES
    (6, 'kamal Perera', '2025-01-28 14:00:00', '2025-01-28 22:00:00', 1, 'Evening', 'Scheduled', 'Usher shift - Hall A Evening');
    PRINT 'Added schedule for kamal Perera.';
END

-- ========================================
-- 5. ADD FOREIGN KEY CONSTRAINTS (SAFELY)
-- ========================================

-- Add foreign key constraint for staff_schedules.staff_id if it doesn't exist
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_staff_schedules_staff')
BEGIN
    BEGIN TRY
        ALTER TABLE [dbo].[staff_schedules] ADD CONSTRAINT FK_staff_schedules_staff 
        FOREIGN KEY ([staff_id]) REFERENCES [dbo].[staff]([id]) ON DELETE CASCADE;
        PRINT 'Added foreign key constraint FK_staff_schedules_staff.';
    END TRY
    BEGIN CATCH
        PRINT 'Warning: Could not add foreign key constraint FK_staff_schedules_staff. Some data may not be valid.';
    END CATCH
END

-- Add foreign key constraint for staff_schedules.hall_id if it doesn't exist
-- Note: This assumes cinema_halls table exists with hall_id column
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_staff_schedules_cinema_halls')
BEGIN
    BEGIN TRY
        ALTER TABLE [dbo].[staff_schedules] ADD CONSTRAINT FK_staff_schedules_cinema_halls 
        FOREIGN KEY ([hall_id]) REFERENCES [dbo].[cinema_halls]([hall_id]);
        PRINT 'Added foreign key constraint FK_staff_schedules_cinema_halls.';
    END TRY
    BEGIN CATCH
        PRINT 'Warning: Could not add foreign key constraint FK_staff_schedules_cinema_halls. Cinema_halls table may not exist.';
    END CATCH
END

-- ========================================
-- 6. CREATE INDEXES FOR PERFORMANCE
-- ========================================

-- Create index on staff_schedules.staff_id for faster lookups
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_staff_schedules_staff_id')
BEGIN
    CREATE INDEX IX_staff_schedules_staff_id ON [dbo].[staff_schedules] ([staff_id]);
    PRINT 'Created index IX_staff_schedules_staff_id.';
END

-- Create index on staff_schedules.hall_id for faster lookups
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_staff_schedules_hall_id')
BEGIN
    CREATE INDEX IX_staff_schedules_hall_id ON [dbo].[staff_schedules] ([hall_id]);
    PRINT 'Created index IX_staff_schedules_hall_id.';
END

-- Create index on staff_schedules.start_time for faster date queries
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_staff_schedules_start_time')
BEGIN
    CREATE INDEX IX_staff_schedules_start_time ON [dbo].[staff_schedules] ([start_time]);
    PRINT 'Created index IX_staff_schedules_start_time.';
END

-- Create index on staff_schedules.status for faster status queries
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_staff_schedules_status')
BEGIN
    CREATE INDEX IX_staff_schedules_status ON [dbo].[staff_schedules] ([status]);
    PRINT 'Created index IX_staff_schedules_status.';
END

-- ========================================
-- 7. VERIFY DATA INTEGRITY
-- ========================================

-- Check for any remaining NULL staff_id values
DECLARE @null_count INT;
SELECT @null_count = COUNT(*) FROM [dbo].[staff_schedules] WHERE [staff_id] IS NULL;

IF @null_count > 0
BEGIN
    PRINT 'Warning: ' + CAST(@null_count AS NVARCHAR(10)) + ' schedules still have NULL staff_id values.';
END
ELSE
BEGIN
    PRINT 'All schedules now have valid staff_id values.';
END

-- Display summary of schedules
SELECT 
    COUNT(*) as total_schedules,
    COUNT(DISTINCT staff_id) as unique_staff,
    COUNT(DISTINCT hall_id) as unique_halls
FROM [dbo].[staff_schedules];

PRINT 'Staff Schedules Data Fix Completed Successfully!';
PRINT 'Updated staff_id values for existing schedules';
PRINT 'Added missing columns with default values';
PRINT 'Added schedules for all staff members';
PRINT 'Created foreign key constraints and indexes';
