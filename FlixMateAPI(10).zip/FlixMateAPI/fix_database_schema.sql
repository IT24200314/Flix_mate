-- Fix Database Schema Conflicts
-- This script removes problematic indexes and constraints that conflict with Hibernate DDL

USE FLIXMATE_2_0;

-- Drop problematic indexes that are causing conflicts
IF EXISTS (SELECT * FROM sys.indexes WHERE name = 'idx_booking_date' AND object_id = OBJECT_ID('bookings'))
    DROP INDEX [idx_booking_date] ON [dbo].[bookings];

IF EXISTS (SELECT * FROM sys.indexes WHERE name = 'idx_user_status' AND object_id = OBJECT_ID('bookings'))
    DROP INDEX [idx_user_status] ON [dbo].[bookings];

IF EXISTS (SELECT * FROM sys.indexes WHERE name = 'idx_hall_status' AND object_id = OBJECT_ID('seats'))
    DROP INDEX [idx_hall_status] ON [dbo].[seats];

IF EXISTS (SELECT * FROM sys.indexes WHERE name = 'idx_payment_status' AND object_id = OBJECT_ID('payments'))
    DROP INDEX [idx_payment_status] ON [dbo].[payments];

-- Drop unique constraints that are causing conflicts
IF EXISTS (SELECT * FROM sys.objects WHERE name = 'UQ__discount__357D4CF95DA53E64')
    ALTER TABLE [dbo].[discount_codes] DROP CONSTRAINT [UQ__discount__357D4CF95DA53E64];

IF EXISTS (SELECT * FROM sys.objects WHERE name = 'UQ__user_sta__501B375389F140DF')
    ALTER TABLE [dbo].[user_status] DROP CONSTRAINT [UQ__user_sta__501B375389F140DF];

-- Drop default constraints that are causing conflicts
IF EXISTS (SELECT * FROM sys.objects WHERE name = 'DF__discount___min_p__73BA3083')
    ALTER TABLE [dbo].[discount_codes] DROP CONSTRAINT [DF__discount___min_p__73BA3083];

-- Recreate the unique constraints with proper names
ALTER TABLE [dbo].[discount_codes] ADD CONSTRAINT [UK_discount_codes_code] UNIQUE ([code]);
ALTER TABLE [dbo].[user_status] ADD CONSTRAINT [UK_user_status_name] UNIQUE ([status_name]);

-- Recreate indexes with proper names (optional, for performance)
CREATE INDEX [IX_bookings_booking_date] ON [dbo].[bookings] ([booking_date]);
CREATE INDEX [IX_bookings_user_status] ON [dbo].[bookings] ([user_id], [status]);
CREATE INDEX [IX_seats_hall_status] ON [dbo].[seats] ([hall_id], [status]);
CREATE INDEX [IX_payments_status] ON [dbo].[payments] ([status]);

PRINT 'Database schema conflicts fixed successfully!';
