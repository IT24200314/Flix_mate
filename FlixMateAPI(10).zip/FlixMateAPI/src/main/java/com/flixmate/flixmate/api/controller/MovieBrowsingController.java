package com.flixmate.flixmate.api.controller;

import com.flixmate.flixmate.api.entity.Movie;
import com.flixmate.flixmate.api.service.MovieService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

/**
 * Controller for guest movie browsing functionality
 * Provides movie browsing, filtering, and search capabilities for unregistered users
 */
@RestController
@RequestMapping("/api/guest/movies")
@CrossOrigin(origins = "*")
public class MovieBrowsingController {

    @Autowired
    private MovieService movieService;

    /**
     * Get all active movies for browsing
     * @return List of active movies
     */
    @GetMapping("/browse")
    public ResponseEntity<?> browseMovies() {
        try {
            System.out.println("=== GUEST MOVIE BROWSING API CALL START ===");
            
            List<Movie> movies = movieService.getAllMovies();
            System.out.println("Total movies from service: " + movies.size());
            
            // Filter active movies and set poster URLs
            List<Movie> activeMovies = movies.stream()
                    .filter(movie -> movie.getIsActive() == null || movie.getIsActive())
                    .peek(movie -> {
                        // Fix null or empty titles
                        if (movie.getTitle() == null || movie.getTitle().trim().isEmpty()) {
                            System.out.println("WARNING: Movie ID " + movie.getMovieId() + " has null/empty title, setting fallback");
                            movie.setTitle("Movie " + movie.getMovieId());
                        }
                        
                        if (movie.getPosterUrl() == null || movie.getPosterUrl().isEmpty()) {
                            movie.setPosterUrl(generatePosterUrl(movie.getMovieId()));
                        }
                        System.out.println("Movie: " + movie.getTitle() + " - Active: " + movie.getIsActive());
                    })
                    .toList();
            
            System.out.println("Active movies for browsing: " + activeMovies.size());
            System.out.println("=== GUEST MOVIE BROWSING API CALL END ===");
            
            return ResponseEntity.ok(activeMovies);
        } catch (Exception e) {
            System.err.println("=== GUEST MOVIE BROWSING API ERROR ===");
            System.err.println("Error: " + e.getMessage());
            e.printStackTrace();
            System.err.println("=== END GUEST MOVIE BROWSING API ERROR ===");
            
            return ResponseEntity.status(500).body(Map.of(
                "error", "Failed to browse movies",
                "message", e.getMessage(),
                "timestamp", System.currentTimeMillis()
            ));
        }
    }

    /**
     * Search movies with filters
     * @param title Movie title search term
     * @param genre Movie genre filter
     * @param year Release year filter
     * @param rating Movie rating filter
     * @param language Movie language filter
     * @return Filtered list of movies
     */
    @GetMapping("/search")
    public ResponseEntity<?> searchMovies(
            @RequestParam(required = false) String title,
            @RequestParam(required = false) String genre,
            @RequestParam(required = false) Integer year,
            @RequestParam(required = false) String rating,
            @RequestParam(required = false) String language) {
        
        try {
            System.out.println("=== GUEST MOVIE SEARCH API CALL START ===");
            System.out.println("Search params - Title: " + title + ", Genre: " + genre + 
                             ", Year: " + year + ", Rating: " + rating + ", Language: " + language);
            
            List<Movie> allMovies = movieService.getAllMovies();
            List<Movie> filteredMovies = allMovies.stream()
                    .filter(movie -> movie.getIsActive() == null || movie.getIsActive())
                    .filter(movie -> title == null || title.isEmpty() || 
                            movie.getTitle().toLowerCase().contains(title.toLowerCase()))
                    .filter(movie -> genre == null || genre.isEmpty() || 
                            (movie.getGenre() != null && movie.getGenre().toLowerCase().contains(genre.toLowerCase())))
                    .filter(movie -> year == null || movie.getReleaseYear().equals(year))
                    .filter(movie -> rating == null || rating.isEmpty() || 
                            (movie.getRating() != null && movie.getRating().equals(rating)))
                    .filter(movie -> language == null || language.isEmpty() || 
                            (movie.getLanguage() != null && movie.getLanguage().toLowerCase().contains(language.toLowerCase())))
                    .peek(movie -> {
                        if (movie.getPosterUrl() == null || movie.getPosterUrl().isEmpty()) {
                            movie.setPosterUrl(generatePosterUrl(movie.getMovieId()));
                        }
                    })
                    .toList();
            
            System.out.println("Filtered movies count: " + filteredMovies.size());
            System.out.println("=== GUEST MOVIE SEARCH API CALL END ===");
            
            return ResponseEntity.ok(filteredMovies);
        } catch (Exception e) {
            System.err.println("=== GUEST MOVIE SEARCH API ERROR ===");
            System.err.println("Error: " + e.getMessage());
            e.printStackTrace();
            System.err.println("=== END GUEST MOVIE SEARCH API ERROR ===");
            
            return ResponseEntity.status(500).body(Map.of(
                "error", "Failed to search movies",
                "message", e.getMessage(),
                "timestamp", System.currentTimeMillis()
            ));
        }
    }

    /**
     * Get movie details by ID for browsing
     * @param id Movie ID
     * @return Movie details
     */
    @GetMapping("/{id}")
    public ResponseEntity<?> getMovieDetails(@PathVariable Integer id) {
        try {
            System.out.println("=== GUEST MOVIE DETAILS API CALL START ===");
            System.out.println("Movie ID: " + id);
            
            Movie movie = movieService.getMovieById(id);
            if (movie != null && (movie.getIsActive() == null || movie.getIsActive())) {
                if (movie.getPosterUrl() == null || movie.getPosterUrl().isEmpty()) {
                    movie.setPosterUrl(generatePosterUrl(movie.getMovieId()));
                }
                
                System.out.println("Movie found: " + movie.getTitle());
                System.out.println("=== GUEST MOVIE DETAILS API CALL END ===");
                return ResponseEntity.ok(movie);
            } else {
                System.out.println("Movie not found or inactive");
                System.out.println("=== GUEST MOVIE DETAILS API CALL END ===");
                return ResponseEntity.notFound().build();
            }
        } catch (Exception e) {
            System.err.println("=== GUEST MOVIE DETAILS API ERROR ===");
            System.err.println("Error: " + e.getMessage());
            e.printStackTrace();
            System.err.println("=== END GUEST MOVIE DETAILS API ERROR ===");
            
            return ResponseEntity.status(500).body(Map.of(
                "error", "Failed to get movie details",
                "message", e.getMessage(),
                "timestamp", System.currentTimeMillis()
            ));
        }
    }

    /**
     * Get available genres for filtering
     * @return List of available genres
     */
    @GetMapping("/genres")
    public ResponseEntity<?> getAvailableGenres() {
        try {
            List<Movie> movies = movieService.getAllMovies();
            List<String> genres = movies.stream()
                    .filter(movie -> movie.getIsActive() == null || movie.getIsActive())
                    .map(Movie::getGenre)
                    .filter(genre -> genre != null && !genre.trim().isEmpty())
                    .distinct()
                    .sorted()
                    .toList();
            return ResponseEntity.ok(genres);
        } catch (Exception e) {
            System.err.println("Error fetching genres: " + e.getMessage());
            return ResponseEntity.badRequest().body("Failed to fetch genres: " + e.getMessage());
        }
    }

    /**
     * Get available years for filtering
     * @return List of available years
     */
    @GetMapping("/years")
    public ResponseEntity<?> getAvailableYears() {
        try {
            List<Movie> movies = movieService.getAllMovies();
            List<Integer> years = movies.stream()
                    .filter(movie -> movie.getIsActive() == null || movie.getIsActive())
                    .map(Movie::getReleaseYear)
                    .filter(year -> year != null)
                    .distinct()
                    .sorted((a, b) -> b.compareTo(a)) // Sort descending
                    .toList();
            return ResponseEntity.ok(years);
        } catch (Exception e) {
            System.err.println("Error fetching years: " + e.getMessage());
            return ResponseEntity.badRequest().body("Failed to fetch years: " + e.getMessage());
        }
    }

    /**
     * Get available ratings for filtering
     * @return List of available ratings
     */
    @GetMapping("/ratings")
    public ResponseEntity<?> getAvailableRatings() {
        try {
            List<Movie> movies = movieService.getAllMovies();
            List<String> ratings = movies.stream()
                    .filter(movie -> movie.getIsActive() == null || movie.getIsActive())
                    .map(Movie::getRating)
                    .filter(rating -> rating != null && !rating.trim().isEmpty())
                    .distinct()
                    .sorted()
                    .toList();
            return ResponseEntity.ok(ratings);
        } catch (Exception e) {
            System.err.println("Error fetching ratings: " + e.getMessage());
            return ResponseEntity.badRequest().body("Failed to fetch ratings: " + e.getMessage());
        }
    }

    /**
     * Get available languages for filtering
     * @return List of available languages
     */
    @GetMapping("/languages")
    public ResponseEntity<?> getAvailableLanguages() {
        try {
            List<Movie> movies = movieService.getAllMovies();
            List<String> languages = movies.stream()
                    .filter(movie -> movie.getIsActive() == null || movie.getIsActive())
                    .map(Movie::getLanguage)
                    .filter(language -> language != null && !language.trim().isEmpty())
                    .distinct()
                    .sorted()
                    .toList();
            return ResponseEntity.ok(languages);
        } catch (Exception e) {
            System.err.println("Error fetching languages: " + e.getMessage());
            return ResponseEntity.badRequest().body("Failed to fetch languages: " + e.getMessage());
        }
    }

    /**
     * Get featured movies for homepage
     * @return List of featured movies
     */
    @GetMapping("/featured")
    public ResponseEntity<?> getFeaturedMovies() {
        try {
            List<Movie> allMovies = movieService.getAllMovies();
            List<Movie> featuredMovies = allMovies.stream()
                    .filter(movie -> movie.getIsActive() == null || movie.getIsActive())
                    .limit(6) // Return top 6 movies as featured
                    .peek(movie -> {
                        if (movie.getPosterUrl() == null || movie.getPosterUrl().isEmpty()) {
                            movie.setPosterUrl(generatePosterUrl(movie.getMovieId()));
                        }
                    })
                    .toList();
            return ResponseEntity.ok(featuredMovies);
        } catch (Exception e) {
            System.err.println("Error fetching featured movies: " + e.getMessage());
            return ResponseEntity.badRequest().body("Failed to fetch featured movies: " + e.getMessage());
        }
    }

    /**
     * Helper method to generate poster URLs
     */
    private String generatePosterUrl(Integer movieId) {
        if (movieId == null) return null;
        
        String[] availablePosters = {
            "movie_12bcc189-4bcf-4780-aaa4-1c5360b1e8f1.png",
            "movie_1ea930ff-f2e9-42d6-b560-5eba79dc4112.png",
            "movie_244ff64f-00d4-4c7d-91f8-6a186603ff41.png",
            "movie_9c136ae0-1345-4de0-8205-3c9d7a74ccae.png",
            "movie_9c3b2a8e-de38-4374-8608-41ccdacef4ac.png",
            "movie_a3c0501b-7516-4be0-8804-0b9ff66cbbf9.png",
            "movie_ad41b530-1a80-4db6-91af-c318e8a3b2d3.png",
            "movie_b1b55829-8f62-4e42-8e97-5e7b4209835c.png",
            "movie_b92cb7c6-bd0c-4e39-8a48-7d805c0944ac.png",
            "movie_bc4bbf60-c9d4-46c5-a95b-7ce8c44ed68c.png",
            "movie_e2f1ce42-0f35-4e2f-bb6c-fcf57f8c02cd.png"
        };
        
        int posterIndex = movieId % availablePosters.length;
        return "static/images/" + availablePosters[posterIndex];
    }
}
