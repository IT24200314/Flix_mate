package com.flixmate.flixmate.api.controller;

import com.flixmate.flixmate.api.entity.Seat;
import com.flixmate.flixmate.api.entity.ShowTime;
import com.flixmate.flixmate.api.entity.Booking;
import com.flixmate.flixmate.api.service.BookingService;
import com.flixmate.flixmate.api.repository.SeatRepository;
import com.flixmate.flixmate.api.repository.ShowTimeRepository;
import com.flixmate.flixmate.api.repository.BookingRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/seats")
public class SeatAvailabilityController {
    
    @Autowired
    private BookingService bookingService;
    
    @Autowired
    private SeatRepository seatRepository;
    
    @Autowired
    private ShowTimeRepository showTimeRepository;
    
    @Autowired
    private BookingRepository bookingRepository;
    
    @GetMapping("/available/{showtimeId}")
    public ResponseEntity<List<Seat>> getAvailableSeats(@PathVariable Integer showtimeId) {
        try {
            List<Seat> seats = bookingService.getAvailableSeats(showtimeId);
            return ResponseEntity.ok(seats);
        } catch (Exception e) {
            return ResponseEntity.badRequest().build();
        }
    }
    
    @GetMapping("/refresh/{showtimeId}")
    public ResponseEntity<List<Seat>> refreshSeatAvailability(@PathVariable Integer showtimeId) {
        try {
            List<Seat> seats = bookingService.getAvailableSeats(showtimeId);
            return ResponseEntity.ok(seats);
        } catch (Exception e) {
            return ResponseEntity.badRequest().build();
        }
    }
    
    /**
     * Get comprehensive seat availability for a showtime (public access)
     * This endpoint provides real-time seat availability considering actual bookings
     */
    @GetMapping("/availability/{showtimeId}")
    public ResponseEntity<?> getComprehensiveSeatAvailability(@PathVariable Integer showtimeId) {
        try {
            System.out.println("=== PUBLIC SEAT AVAILABILITY API CALL START ===");
            System.out.println("Showtime ID: " + showtimeId);
            
            // Get showtime details
            ShowTime showtime = showTimeRepository.findById(showtimeId)
                    .orElseThrow(() -> new RuntimeException("Showtime not found with ID: " + showtimeId));
            
            // Check if showtime is in the future
            if (showtime.getStartTime().isBefore(LocalDateTime.now())) {
                return ResponseEntity.badRequest().body(Map.of(
                    "error", "Showtime has already passed",
                    "message", "This showtime is no longer available"
                ));
            }
            
            // Get all seats for the cinema hall
            List<Seat> allSeats = seatRepository.findByCinemaHall(showtime.getCinemaHall());
            
            // Get confirmed bookings for this showtime
            List<Booking> confirmedBookings = bookingRepository.findByShowtime(showtime).stream()
                    .filter(booking -> "CONFIRMED".equals(booking.getStatus()))
                    .collect(Collectors.toList());
            
            // Get seat IDs that are actually booked
            Set<Integer> bookedSeatIds = confirmedBookings.stream()
                    .flatMap(booking -> booking.getSeats().stream())
                    .map(Seat::getSeatId)
                    .collect(Collectors.toSet());
            
            // Create seat availability map
            List<Map<String, Object>> seatAvailability = new ArrayList<>();
            
            for (Seat seat : allSeats) {
                Map<String, Object> seatInfo = new HashMap<>();
                seatInfo.put("seatId", seat.getSeatId());
                seatInfo.put("row", seat.getRow());
                seatInfo.put("number", seat.getNumber());
                
                // Determine actual availability
                boolean isBooked = bookedSeatIds.contains(seat.getSeatId());
                String actualStatus;
                
                if (isBooked) {
                    actualStatus = "OCCUPIED";
                } else if ("MAINTENANCE".equals(seat.getStatus())) {
                    actualStatus = "MAINTENANCE";
                } else if ("RESERVED".equals(seat.getStatus())) {
                    actualStatus = "RESERVED";
                } else {
                    actualStatus = "AVAILABLE";
                }
                
                seatInfo.put("status", actualStatus);
                seatInfo.put("isAvailable", "AVAILABLE".equals(actualStatus));
                seatInfo.put("isBooked", isBooked);
                
                seatAvailability.add(seatInfo);
            }
            
            // Calculate statistics
            int totalSeats = allSeats.size();
            int availableSeats = (int) seatAvailability.stream()
                    .filter(seat -> "AVAILABLE".equals(seat.get("status")))
                    .count();
            int occupiedSeats = (int) seatAvailability.stream()
                    .filter(seat -> "OCCUPIED".equals(seat.get("status")))
                    .count();
            int reservedSeats = (int) seatAvailability.stream()
                    .filter(seat -> "RESERVED".equals(seat.get("status")))
                    .count();
            int maintenanceSeats = (int) seatAvailability.stream()
                    .filter(seat -> "MAINTENANCE".equals(seat.get("status")))
                    .count();
            
            // Calculate availability percentage
            double availabilityPercentage = totalSeats > 0 ? 
                (double) availableSeats / totalSeats * 100 : 0;
            
            Map<String, Object> response = new HashMap<>();
            response.put("showtimeId", showtimeId);
            response.put("showtime", Map.of(
                "startTime", showtime.getStartTime(),
                "endTime", showtime.getEndTime(),
                "price", showtime.getPrice(),
                "hallId", showtime.getCinemaHall().getHallId(),
                "hallName", showtime.getCinemaHall().getName()
            ));
            response.put("totalSeats", totalSeats);
            response.put("availableSeats", availableSeats);
            response.put("occupiedSeats", occupiedSeats);
            response.put("reservedSeats", reservedSeats);
            response.put("maintenanceSeats", maintenanceSeats);
            response.put("availabilityPercentage", Math.round(availabilityPercentage * 100.0) / 100.0);
            response.put("isAvailable", availableSeats > 0);
            response.put("seats", seatAvailability);
            response.put("timestamp", System.currentTimeMillis());
            
            System.out.println("Seat availability: " + availableSeats + "/" + totalSeats + 
                             " (Available/Occupied/Reserved/Maintenance: " + 
                             availableSeats + "/" + occupiedSeats + "/" + reservedSeats + "/" + maintenanceSeats + ")");
            System.out.println("=== PUBLIC SEAT AVAILABILITY API CALL END ===");
            
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            System.err.println("=== PUBLIC SEAT AVAILABILITY API ERROR ===");
            System.err.println("Error: " + e.getMessage());
            e.printStackTrace();
            System.err.println("=== END PUBLIC SEAT AVAILABILITY API ERROR ===");
            
            return ResponseEntity.status(500).body(Map.of(
                "error", "Failed to get seat availability",
                "message", e.getMessage(),
                "timestamp", System.currentTimeMillis()
            ));
        }
    }
}
