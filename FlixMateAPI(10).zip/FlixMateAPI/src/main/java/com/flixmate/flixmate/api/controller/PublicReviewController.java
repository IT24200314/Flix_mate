package com.flixmate.flixmate.api.controller;

import com.flixmate.flixmate.api.entity.Review;
import com.flixmate.flixmate.api.service.ReviewService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/api/public/reviews")
public class PublicReviewController {

    @Autowired
    private ReviewService reviewService;

    @GetMapping
    public ResponseEntity<List<Review>> getAllReviews() {
        try {
            List<Review> reviews = reviewService.getAllReviews();
            return ResponseEntity.ok(reviews);
        } catch (Exception e) {
            List<Review> emptyList = new ArrayList<>();
            return ResponseEntity.ok(emptyList);
        }
    }

    @GetMapping("/movie/{movieId}")
    public ResponseEntity<List<Review>> getMovieReviews(@PathVariable Integer movieId) {
        try {
            List<Review> reviews = reviewService.getMovieReviews(movieId);
            return ResponseEntity.ok(reviews);
        } catch (Exception e) {
            List<Review> emptyList = new ArrayList<>();
            return ResponseEntity.ok(emptyList);
        }
    }
}
