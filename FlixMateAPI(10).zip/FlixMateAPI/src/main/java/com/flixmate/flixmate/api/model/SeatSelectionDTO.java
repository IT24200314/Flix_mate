package com.flixmate.flixmate.api.model;

import java.util.List;

/**
 * DTO for seat selection functionality
 * Used for guest seat map viewing and selection
 */
public class SeatSelectionDTO {
    
    private Integer seatId;
    private String row;
    private Integer number;
    private String status; // AVAILABLE, OCCUPIED, RESERVED, SELECTED
    
    // Showtime information
    private Integer showtimeId;
    private String movieTitle;
    private String showtimeDateTime;
    private Double pricePerSeat;
    
    // Cinema hall information
    private Integer hallId;
    private String hallName;
    private Integer hallCapacity;
    
    // Selection data
    private List<Integer> selectedSeatIds;
    private List<SeatInfo> selectedSeats;
    private Integer totalSelectedSeats;
    private Double totalAmount;
    
    // Seat map data
    private List<SeatInfo> allSeats;
    private List<SeatInfo> availableSeats;
    private List<SeatInfo> occupiedSeats;
    private Integer totalSeats;
    private Integer availableSeatCount;
    private Integer occupiedSeatCount;
    
    // Response metadata
    private Boolean isAvailable;
    private String availabilityStatus;
    private Double availabilityPercentage;

    // Nested class for seat information
    public static class SeatInfo {
        private Integer seatId;
        private String row;
        private Integer number;
        private String status;
        
        public SeatInfo() {}
        
        public SeatInfo(Integer seatId, String row, Integer number, String status) {
            this.seatId = seatId;
            this.row = row;
            this.number = number;
            this.status = status;
        }
        
        // Getters and setters
        public Integer getSeatId() { return seatId; }
        public void setSeatId(Integer seatId) { this.seatId = seatId; }
        
        public String getRow() { return row; }
        public void setRow(String row) { this.row = row; }
        
        public Integer getNumber() { return number; }
        public void setNumber(Integer number) { this.number = number; }
        
        public String getStatus() { return status; }
        public void setStatus(String status) { this.status = status; }
        
        @Override
        public String toString() {
            return "SeatInfo{" +
                    "seatId=" + seatId +
                    ", row='" + row + '\'' +
                    ", number=" + number +
                    ", status='" + status + '\'' +
                    '}';
        }
    }

    // Constructors
    public SeatSelectionDTO() {}

    public SeatSelectionDTO(Integer seatId, String row, Integer number, String status) {
        this.seatId = seatId;
        this.row = row;
        this.number = number;
        this.status = status;
    }

    // Getters and setters
    public Integer getSeatId() { return seatId; }
    public void setSeatId(Integer seatId) { this.seatId = seatId; }

    public String getRow() { return row; }
    public void setRow(String row) { this.row = row; }

    public Integer getNumber() { return number; }
    public void setNumber(Integer number) { this.number = number; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public Integer getShowtimeId() { return showtimeId; }
    public void setShowtimeId(Integer showtimeId) { this.showtimeId = showtimeId; }

    public String getMovieTitle() { return movieTitle; }
    public void setMovieTitle(String movieTitle) { this.movieTitle = movieTitle; }

    public String getShowtimeDateTime() { return showtimeDateTime; }
    public void setShowtimeDateTime(String showtimeDateTime) { this.showtimeDateTime = showtimeDateTime; }

    public Double getPricePerSeat() { return pricePerSeat; }
    public void setPricePerSeat(Double pricePerSeat) { this.pricePerSeat = pricePerSeat; }

    public Integer getHallId() { return hallId; }
    public void setHallId(Integer hallId) { this.hallId = hallId; }

    public String getHallName() { return hallName; }
    public void setHallName(String hallName) { this.hallName = hallName; }

    public Integer getHallCapacity() { return hallCapacity; }
    public void setHallCapacity(Integer hallCapacity) { this.hallCapacity = hallCapacity; }

    public List<Integer> getSelectedSeatIds() { return selectedSeatIds; }
    public void setSelectedSeatIds(List<Integer> selectedSeatIds) { this.selectedSeatIds = selectedSeatIds; }

    public List<SeatInfo> getSelectedSeats() { return selectedSeats; }
    public void setSelectedSeats(List<SeatInfo> selectedSeats) { this.selectedSeats = selectedSeats; }

    public Integer getTotalSelectedSeats() { return totalSelectedSeats; }
    public void setTotalSelectedSeats(Integer totalSelectedSeats) { this.totalSelectedSeats = totalSelectedSeats; }

    public Double getTotalAmount() { return totalAmount; }
    public void setTotalAmount(Double totalAmount) { this.totalAmount = totalAmount; }

    public List<SeatInfo> getAllSeats() { return allSeats; }
    public void setAllSeats(List<SeatInfo> allSeats) { this.allSeats = allSeats; }

    public List<SeatInfo> getAvailableSeats() { return availableSeats; }
    public void setAvailableSeats(List<SeatInfo> availableSeats) { this.availableSeats = availableSeats; }

    public List<SeatInfo> getOccupiedSeats() { return occupiedSeats; }
    public void setOccupiedSeats(List<SeatInfo> occupiedSeats) { this.occupiedSeats = occupiedSeats; }

    public Integer getTotalSeats() { return totalSeats; }
    public void setTotalSeats(Integer totalSeats) { this.totalSeats = totalSeats; }

    public Integer getAvailableSeatCount() { return availableSeatCount; }
    public void setAvailableSeatCount(Integer availableSeatCount) { this.availableSeatCount = availableSeatCount; }

    public Integer getOccupiedSeatCount() { return occupiedSeatCount; }
    public void setOccupiedSeatCount(Integer occupiedSeatCount) { this.occupiedSeatCount = occupiedSeatCount; }

    public Boolean getIsAvailable() { return isAvailable; }
    public void setIsAvailable(Boolean isAvailable) { this.isAvailable = isAvailable; }

    public String getAvailabilityStatus() { return availabilityStatus; }
    public void setAvailabilityStatus(String availabilityStatus) { this.availabilityStatus = availabilityStatus; }

    public Double getAvailabilityPercentage() { return availabilityPercentage; }
    public void setAvailabilityPercentage(Double availabilityPercentage) { this.availabilityPercentage = availabilityPercentage; }

    @Override
    public String toString() {
        return "SeatSelectionDTO{" +
                "seatId=" + seatId +
                ", row='" + row + '\'' +
                ", number=" + number +
                ", status='" + status + '\'' +
                ", showtimeId=" + showtimeId +
                ", totalSelectedSeats=" + totalSelectedSeats +
                ", totalAmount=" + totalAmount +
                '}';
    }
}
