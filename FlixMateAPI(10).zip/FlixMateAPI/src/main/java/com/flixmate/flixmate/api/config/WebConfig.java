package com.flixmate.flixmate.api.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
public class WebConfig implements WebMvcConfigurer {

    @Override
    public void addResourceHandlers(ResourceHandlerRegistry registry) {
        // Serve specific static file types from webapp directory
        registry.addResourceHandler("*.html")
                .addResourceLocations("classpath:/webapp/")
                .setCachePeriod(0);
        
        registry.addResourceHandler("*.css")
                .addResourceLocations("classpath:/webapp/")
                .setCachePeriod(0);
        
        registry.addResourceHandler("*.js")
                .addResourceLocations("classpath:/webapp/")
                .setCachePeriod(0);
        
        registry.addResourceHandler("*.png", "*.jpg", "*.jpeg", "*.gif", "*.ico")
                .addResourceLocations("classpath:/webapp/")
                .setCachePeriod(0);
        
        // Serve static images
        registry.addResourceHandler("/static/**")
                .addResourceLocations("classpath:/webapp/static/")
                .setCachePeriod(0);
    }
}
