package com.flixmate.flixmate.api.model;

import java.time.LocalDateTime;
import java.util.List;

/**
 * DTO for showtime selection functionality
 * Used for guest showtime viewing and selection
 */
public class ShowtimeSelectionDTO {
    
    private Integer showtimeId;
    private LocalDateTime startTime;
    private LocalDateTime endTime;
    private Double price;
    
    // Movie information
    private Integer movieId;
    private String movieTitle;
    private Integer movieDuration;
    private String movieRating;
    private String moviePosterUrl;
    
    // Cinema hall information
    private Integer hallId;
    private String hallName;
    private Integer hallCapacity;
    
    // Selection criteria
    private Integer movieIdFilter;
    private LocalDateTime dateFilter;
    private LocalDateTime startTimeFilter;
    private LocalDateTime endTimeFilter;
    
    // Response metadata
    private Boolean isAvailable;
    private String availabilityStatus;
    private Integer availableSeats;
    private Integer totalSeats;
    
    // Pagination
    private Integer page;
    private Integer size;
    private String sortBy;
    private String sortDirection;
    
    // Response metadata
    private Long totalCount;
    private Integer totalPages;
    private Boolean hasNext;
    private Boolean hasPrevious;

    // Constructors
    public ShowtimeSelectionDTO() {}

    public ShowtimeSelectionDTO(Integer showtimeId, LocalDateTime startTime, LocalDateTime endTime, Double price) {
        this.showtimeId = showtimeId;
        this.startTime = startTime;
        this.endTime = endTime;
        this.price = price;
    }

    // Getters and setters
    public Integer getShowtimeId() { return showtimeId; }
    public void setShowtimeId(Integer showtimeId) { this.showtimeId = showtimeId; }

    public LocalDateTime getStartTime() { return startTime; }
    public void setStartTime(LocalDateTime startTime) { this.startTime = startTime; }

    public LocalDateTime getEndTime() { return endTime; }
    public void setEndTime(LocalDateTime endTime) { this.endTime = endTime; }

    public Double getPrice() { return price; }
    public void setPrice(Double price) { this.price = price; }

    public Integer getMovieId() { return movieId; }
    public void setMovieId(Integer movieId) { this.movieId = movieId; }

    public String getMovieTitle() { return movieTitle; }
    public void setMovieTitle(String movieTitle) { this.movieTitle = movieTitle; }

    public Integer getMovieDuration() { return movieDuration; }
    public void setMovieDuration(Integer movieDuration) { this.movieDuration = movieDuration; }

    public String getMovieRating() { return movieRating; }
    public void setMovieRating(String movieRating) { this.movieRating = movieRating; }

    public String getMoviePosterUrl() { return moviePosterUrl; }
    public void setMoviePosterUrl(String moviePosterUrl) { this.moviePosterUrl = moviePosterUrl; }

    public Integer getHallId() { return hallId; }
    public void setHallId(Integer hallId) { this.hallId = hallId; }

    public String getHallName() { return hallName; }
    public void setHallName(String hallName) { this.hallName = hallName; }

    public Integer getHallCapacity() { return hallCapacity; }
    public void setHallCapacity(Integer hallCapacity) { this.hallCapacity = hallCapacity; }

    public Integer getMovieIdFilter() { return movieIdFilter; }
    public void setMovieIdFilter(Integer movieIdFilter) { this.movieIdFilter = movieIdFilter; }

    public LocalDateTime getDateFilter() { return dateFilter; }
    public void setDateFilter(LocalDateTime dateFilter) { this.dateFilter = dateFilter; }

    public LocalDateTime getStartTimeFilter() { return startTimeFilter; }
    public void setStartTimeFilter(LocalDateTime startTimeFilter) { this.startTimeFilter = startTimeFilter; }

    public LocalDateTime getEndTimeFilter() { return endTimeFilter; }
    public void setEndTimeFilter(LocalDateTime endTimeFilter) { this.endTimeFilter = endTimeFilter; }

    public Boolean getIsAvailable() { return isAvailable; }
    public void setIsAvailable(Boolean isAvailable) { this.isAvailable = isAvailable; }

    public String getAvailabilityStatus() { return availabilityStatus; }
    public void setAvailabilityStatus(String availabilityStatus) { this.availabilityStatus = availabilityStatus; }

    public Integer getAvailableSeats() { return availableSeats; }
    public void setAvailableSeats(Integer availableSeats) { this.availableSeats = availableSeats; }

    public Integer getTotalSeats() { return totalSeats; }
    public void setTotalSeats(Integer totalSeats) { this.totalSeats = totalSeats; }

    public Integer getPage() { return page; }
    public void setPage(Integer page) { this.page = page; }

    public Integer getSize() { return size; }
    public void setSize(Integer size) { this.size = size; }

    public String getSortBy() { return sortBy; }
    public void setSortBy(String sortBy) { this.sortBy = sortBy; }

    public String getSortDirection() { return sortDirection; }
    public void setSortDirection(String sortDirection) { this.sortDirection = sortDirection; }

    public Long getTotalCount() { return totalCount; }
    public void setTotalCount(Long totalCount) { this.totalCount = totalCount; }

    public Integer getTotalPages() { return totalPages; }
    public void setTotalPages(Integer totalPages) { this.totalPages = totalPages; }

    public Boolean getHasNext() { return hasNext; }
    public void setHasNext(Boolean hasNext) { this.hasNext = hasNext; }

    public Boolean getHasPrevious() { return hasPrevious; }
    public void setHasPrevious(Boolean hasPrevious) { this.hasPrevious = hasPrevious; }

    @Override
    public String toString() {
        return "ShowtimeSelectionDTO{" +
                "showtimeId=" + showtimeId +
                ", startTime=" + startTime +
                ", endTime=" + endTime +
                ", price=" + price +
                ", movieTitle='" + movieTitle + '\'' +
                ", hallName='" + hallName + '\'' +
                ", isAvailable=" + isAvailable +
                '}';
    }
}
