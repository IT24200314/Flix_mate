package com.flixmate.flixmate.api.controller;

import com.flixmate.flixmate.api.entity.ShowTime;
import com.flixmate.flixmate.api.entity.Seat;
import com.flixmate.flixmate.api.service.ShowTimeService;
import com.flixmate.flixmate.api.service.BookingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import java.util.HashMap;

/**
 * Controller for guest booking functionality
 * Handles guest booking flow and redirects unregistered users to login
 */
@RestController
@RequestMapping("/api/guest/booking")
@CrossOrigin(origins = "*")
public class GuestBookingController {

    @Autowired
    private ShowTimeService showTimeService;

    @Autowired
    private BookingService bookingService;

    /**
     * Validate guest booking request and prepare for login redirect
     * @param request Guest booking request
     * @return Validation result with redirect information
     */
    @PostMapping("/validate")
    public ResponseEntity<?> validateGuestBooking(@RequestBody GuestBookingRequest request) {
        try {
            System.out.println("=== GUEST BOOKING VALIDATION API CALL START ===");
            System.out.println("Showtime ID: " + request.getShowtimeId());
            System.out.println("Selected seats: " + request.getSelectedSeatIds());
            
            // Validate showtime
            ShowTime showtime = showTimeService.getShowTimeById(request.getShowtimeId());
            if (showtime == null) {
                System.out.println("Showtime not found");
                System.out.println("=== GUEST BOOKING VALIDATION API CALL END ===");
                return ResponseEntity.badRequest().body(Map.of(
                    "error", "Showtime not found",
                    "message", "The selected showtime is no longer available"
                ));
            }

            // Check if showtime is in the future
            if (showtime.getStartTime().isBefore(LocalDateTime.now())) {
                System.out.println("Showtime is in the past");
                System.out.println("=== GUEST BOOKING VALIDATION API CALL END ===");
                return ResponseEntity.badRequest().body(Map.of(
                    "error", "Showtime has passed",
                    "message", "This showtime is no longer available"
                ));
            }

            // Validate seats
            if (request.getSelectedSeatIds() == null || request.getSelectedSeatIds().isEmpty()) {
                System.out.println("No seats selected");
                System.out.println("=== GUEST BOOKING VALIDATION API CALL END ===");
                return ResponseEntity.badRequest().body(Map.of(
                    "error", "No seats selected",
                    "message", "Please select at least one seat"
                ));
            }

            // Check seat availability
            List<Seat> availableSeats = bookingService.getAvailableSeats(request.getShowtimeId());
            for (Integer seatId : request.getSelectedSeatIds()) {
                boolean seatAvailable = availableSeats.stream()
                        .anyMatch(seat -> seat.getSeatId().equals(seatId) && 
                                "AVAILABLE".equals(seat.getStatus()));
                if (!seatAvailable) {
                    System.out.println("Seat not available: " + seatId);
                    System.out.println("=== GUEST BOOKING VALIDATION API CALL END ===");
                    return ResponseEntity.badRequest().body(Map.of(
                        "error", "Seat not available",
                        "message", "One or more selected seats are no longer available"
                    ));
                }
            }

            // Calculate total amount
            double totalAmount = request.getSelectedSeatIds().size() * showtime.getPrice();
            
            // Create booking summary for guest
            Map<String, Object> bookingSummary = new HashMap<>();
            bookingSummary.put("showtimeId", showtime.getShowtimeId());
            bookingSummary.put("selectedSeatIds", request.getSelectedSeatIds());
            bookingSummary.put("totalSeats", request.getSelectedSeatIds().size());
            bookingSummary.put("pricePerSeat", showtime.getPrice());
            bookingSummary.put("totalAmount", totalAmount);
            bookingSummary.put("movie", Map.of(
                "movieId", showtime.getMovie().getMovieId(),
                "title", showtime.getMovie().getTitle(),
                "duration", showtime.getMovie().getDuration()
            ));
            bookingSummary.put("showtime", Map.of(
                "startTime", showtime.getStartTime(),
                "endTime", showtime.getEndTime(),
                "price", showtime.getPrice()
            ));
            bookingSummary.put("cinemaHall", Map.of(
                "hallId", showtime.getCinemaHall().getHallId(),
                "hallName", showtime.getCinemaHall().getHallName()
            ));
            bookingSummary.put("requiresLogin", true);
            bookingSummary.put("redirectUrl", "/login.html?redirect=booking&showtimeId=" + 
                showtime.getShowtimeId() + "&seats=" + String.join(",", 
                request.getSelectedSeatIds().stream().map(String::valueOf).toArray(String[]::new)));

            System.out.println("Guest booking validation successful");
            System.out.println("Total amount: " + totalAmount);
            System.out.println("=== GUEST BOOKING VALIDATION API CALL END ===");
            
            return ResponseEntity.ok(bookingSummary);
        } catch (Exception e) {
            System.err.println("=== GUEST BOOKING VALIDATION API ERROR ===");
            System.err.println("Error: " + e.getMessage());
            e.printStackTrace();
            System.err.println("=== END GUEST BOOKING VALIDATION API ERROR ===");
            
            return ResponseEntity.status(500).body(Map.of(
                "error", "Failed to validate booking",
                "message", e.getMessage(),
                "timestamp", System.currentTimeMillis()
            ));
        }
    }

    /**
     * Get guest booking summary for display
     * @param showtimeId Showtime ID
     * @param seatIds Comma-separated seat IDs
     * @return Booking summary
     */
    @GetMapping("/summary")
    public ResponseEntity<?> getGuestBookingSummary(
            @RequestParam Integer showtimeId,
            @RequestParam String seatIds) {
        try {
            System.out.println("=== GUEST BOOKING SUMMARY API CALL START ===");
            System.out.println("Showtime ID: " + showtimeId);
            System.out.println("Seat IDs: " + seatIds);
            
            // Parse seat IDs
            String[] seatIdArray = seatIds.split(",");
            List<Integer> selectedSeatIds = List.of(seatIdArray).stream()
                    .map(String::trim)
                    .map(Integer::parseInt)
                    .toList();

            // Validate showtime
            ShowTime showtime = showTimeService.getShowTimeById(showtimeId);
            if (showtime == null) {
                System.out.println("Showtime not found");
                System.out.println("=== GUEST BOOKING SUMMARY API CALL END ===");
                return ResponseEntity.notFound().build();
            }

            // Calculate total amount
            double totalAmount = selectedSeatIds.size() * showtime.getPrice();
            
            // Create booking summary
            Map<String, Object> summary = Map.of(
                "showtimeId", showtimeId,
                "selectedSeatIds", selectedSeatIds,
                "totalSeats", selectedSeatIds.size(),
                "pricePerSeat", showtime.getPrice(),
                "totalAmount", totalAmount,
                "movie", Map.of(
                    "movieId", showtime.getMovie().getMovieId(),
                    "title", showtime.getMovie().getTitle(),
                    "duration", showtime.getMovie().getDuration(),
                    "posterUrl", showtime.getMovie().getPosterUrl()
                ),
                "showtime", Map.of(
                    "startTime", showtime.getStartTime(),
                    "endTime", showtime.getEndTime(),
                    "price", showtime.getPrice()
                ),
                "cinemaHall", Map.of(
                    "hallId", showtime.getCinemaHall().getHallId(),
                    "hallName", showtime.getCinemaHall().getHallName()
                ),
                "requiresLogin", true,
                "message", "Please login to complete your booking"
            );
            
            System.out.println("Guest booking summary created");
            System.out.println("=== GUEST BOOKING SUMMARY API CALL END ===");
            
            return ResponseEntity.ok(summary);
        } catch (Exception e) {
            System.err.println("=== GUEST BOOKING SUMMARY API ERROR ===");
            System.err.println("Error: " + e.getMessage());
            e.printStackTrace();
            System.err.println("=== END GUEST BOOKING SUMMARY API ERROR ===");
            
            return ResponseEntity.status(500).body(Map.of(
                "error", "Failed to get booking summary",
                "message", e.getMessage(),
                "timestamp", System.currentTimeMillis()
            ));
        }
    }

    /**
     * Check if user is authenticated
     * @return Authentication status
     */
    @GetMapping("/auth-status")
    public ResponseEntity<?> checkAuthStatus() {
        try {
            // This endpoint helps the frontend determine if user is logged in
            // For guests, this will always return false
            Map<String, Object> authStatus = Map.of(
                "isAuthenticated", false,
                "userType", "guest",
                "message", "Guest user - login required for booking"
            );
            
            return ResponseEntity.ok(authStatus);
        } catch (Exception e) {
            System.err.println("Error checking auth status: " + e.getMessage());
            return ResponseEntity.status(500).body(Map.of(
                "error", "Failed to check authentication status",
                "message", e.getMessage()
            ));
        }
    }

    /**
     * Guest booking request DTO
     */
    public static class GuestBookingRequest {
        private Integer showtimeId;
        private List<Integer> selectedSeatIds;
        private String discountCode;
        private Integer loyaltyPoints;

        // Getters and setters
        public Integer getShowtimeId() { return showtimeId; }
        public void setShowtimeId(Integer showtimeId) { this.showtimeId = showtimeId; }
        
        public List<Integer> getSelectedSeatIds() { return selectedSeatIds; }
        public void setSelectedSeatIds(List<Integer> selectedSeatIds) { this.selectedSeatIds = selectedSeatIds; }
        
        public String getDiscountCode() { return discountCode; }
        public void setDiscountCode(String discountCode) { this.discountCode = discountCode; }
        
        public Integer getLoyaltyPoints() { return loyaltyPoints; }
        public void setLoyaltyPoints(Integer loyaltyPoints) { this.loyaltyPoints = loyaltyPoints; }
    }
}
