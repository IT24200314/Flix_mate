package com.flixmate.flixmate.api.controller;

import com.flixmate.flixmate.api.entity.Seat;
import com.flixmate.flixmate.api.entity.ShowTime;
import com.flixmate.flixmate.api.service.BookingService;
import com.flixmate.flixmate.api.service.ShowTimeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * Controller for guest seat map viewing functionality
 * Provides seat map viewing capabilities for unregistered users
 */
@RestController
@RequestMapping("/api/guest/seats")
@CrossOrigin(origins = "*")
public class SeatMapController {

    @Autowired
    private BookingService bookingService;

    @Autowired
    private ShowTimeService showTimeService;

    /**
     * Get seat map for a specific showtime
     * @param showtimeId Showtime ID
     * @return Seat map with availability status
     */
    @GetMapping("/map/{showtimeId}")
    public ResponseEntity<?> getSeatMap(@PathVariable Integer showtimeId) {
        try {
            System.out.println("=== GUEST SEAT MAP API CALL START ===");
            System.out.println("Showtime ID: " + showtimeId);
            
            // Verify showtime exists and is in the future
            ShowTime showtime = showTimeService.getShowTimeById(showtimeId);
            if (showtime == null) {
                System.out.println("Showtime not found");
                System.out.println("=== GUEST SEAT MAP API CALL END ===");
                return ResponseEntity.notFound().build();
            }

            if (showtime.getStartTime().isBefore(LocalDateTime.now())) {
                System.out.println("Showtime is in the past");
                System.out.println("=== GUEST SEAT MAP API CALL END ===");
                return ResponseEntity.badRequest().body(Map.of(
                    "error", "Showtime has already passed",
                    "message", "This showtime is no longer available"
                ));
            }

            // Get seat availability
            List<Seat> seats = bookingService.getAvailableSeats(showtimeId);
            System.out.println("Total seats found: " + seats.size());
            
            // Group seats by row for better organization
            Map<String, List<Seat>> seatsByRow = seats.stream()
                    .collect(Collectors.groupingBy(Seat::getRow));
            
            // Create seat map response
            Map<String, Object> seatMap = Map.of(
                "showtimeId", showtimeId,
                "cinemaHall", Map.of(
                    "hallId", showtime.getCinemaHall().getHallId(),
                    "hallName", showtime.getCinemaHall().getHallName(),
                    "capacity", showtime.getCinemaHall().getCapacity()
                ),
                "movie", Map.of(
                    "movieId", showtime.getMovie().getMovieId(),
                    "title", showtime.getMovie().getTitle(),
                    "duration", showtime.getMovie().getDuration()
                ),
                "showtime", Map.of(
                    "startTime", showtime.getStartTime(),
                    "endTime", showtime.getEndTime(),
                    "price", showtime.getPrice()
                ),
                "seatsByRow", seatsByRow,
                "totalSeats", seats.size(),
                "availableSeats", seats.stream().mapToInt(seat -> 
                    "AVAILABLE".equals(seat.getStatus()) ? 1 : 0).sum(),
                "occupiedSeats", seats.stream().mapToInt(seat -> 
                    "OCCUPIED".equals(seat.getStatus()) ? 1 : 0).sum()
            );
            
            System.out.println("Seat map created successfully");
            System.out.println("=== GUEST SEAT MAP API CALL END ===");
            
            return ResponseEntity.ok(seatMap);
        } catch (Exception e) {
            System.err.println("=== GUEST SEAT MAP API ERROR ===");
            System.err.println("Error: " + e.getMessage());
            e.printStackTrace();
            System.err.println("=== END GUEST SEAT MAP API ERROR ===");
            
            return ResponseEntity.status(500).body(Map.of(
                "error", "Failed to get seat map",
                "message", e.getMessage(),
                "timestamp", System.currentTimeMillis()
            ));
        }
    }

    /**
     * Get seat availability summary for a showtime
     * @param showtimeId Showtime ID
     * @return Seat availability summary
     */
    @GetMapping("/availability/{showtimeId}")
    public ResponseEntity<?> getSeatAvailability(@PathVariable Integer showtimeId) {
        try {
            System.out.println("=== GUEST SEAT AVAILABILITY API CALL START ===");
            System.out.println("Showtime ID: " + showtimeId);
            
            // Verify showtime exists and is in the future
            ShowTime showtime = showTimeService.getShowTimeById(showtimeId);
            if (showtime == null) {
                System.out.println("Showtime not found");
                System.out.println("=== GUEST SEAT AVAILABILITY API CALL END ===");
                return ResponseEntity.notFound().build();
            }

            if (showtime.getStartTime().isBefore(LocalDateTime.now())) {
                System.out.println("Showtime is in the past");
                System.out.println("=== GUEST SEAT AVAILABILITY API CALL END ===");
                return ResponseEntity.badRequest().body(Map.of(
                    "error", "Showtime has already passed",
                    "message", "This showtime is no longer available"
                ));
            }

            // Get seat availability
            List<Seat> seats = bookingService.getAvailableSeats(showtimeId);
            
            int totalSeats = seats.size();
            int availableSeats = (int) seats.stream()
                    .filter(seat -> "AVAILABLE".equals(seat.getStatus()))
                    .count();
            int occupiedSeats = totalSeats - availableSeats;
            
            // Calculate availability percentage
            double availabilityPercentage = totalSeats > 0 ? 
                (double) availableSeats / totalSeats * 100 : 0;
            
            Map<String, Object> availability = Map.of(
                "showtimeId", showtimeId,
                "totalSeats", totalSeats,
                "availableSeats", availableSeats,
                "occupiedSeats", occupiedSeats,
                "availabilityPercentage", Math.round(availabilityPercentage * 100.0) / 100.0,
                "isAvailable", availableSeats > 0,
                "showtime", Map.of(
                    "startTime", showtime.getStartTime(),
                    "price", showtime.getPrice()
                )
            );
            
            System.out.println("Seat availability: " + availableSeats + "/" + totalSeats);
            System.out.println("=== GUEST SEAT AVAILABILITY API CALL END ===");
            
            return ResponseEntity.ok(availability);
        } catch (Exception e) {
            System.err.println("=== GUEST SEAT AVAILABILITY API ERROR ===");
            System.err.println("Error: " + e.getMessage());
            e.printStackTrace();
            System.err.println("=== END GUEST SEAT AVAILABILITY API ERROR ===");
            
            return ResponseEntity.status(500).body(Map.of(
                "error", "Failed to get seat availability",
                "message", e.getMessage(),
                "timestamp", System.currentTimeMillis()
            ));
        }
    }

    /**
     * Refresh seat availability for real-time updates
     * @param showtimeId Showtime ID
     * @return Updated seat availability
     */
    @GetMapping("/refresh/{showtimeId}")
    public ResponseEntity<?> refreshSeatAvailability(@PathVariable Integer showtimeId) {
        try {
            System.out.println("=== GUEST SEAT REFRESH API CALL START ===");
            System.out.println("Showtime ID: " + showtimeId);
            
            // Verify showtime exists and is in the future
            ShowTime showtime = showTimeService.getShowTimeById(showtimeId);
            if (showtime == null) {
                System.out.println("Showtime not found");
                System.out.println("=== GUEST SEAT REFRESH API CALL END ===");
                return ResponseEntity.notFound().build();
            }

            if (showtime.getStartTime().isBefore(LocalDateTime.now())) {
                System.out.println("Showtime is in the past");
                System.out.println("=== GUEST SEAT REFRESH API CALL END ===");
                return ResponseEntity.badRequest().body(Map.of(
                    "error", "Showtime has already passed",
                    "message", "This showtime is no longer available"
                ));
            }

            // Get updated seat availability
            List<Seat> seats = bookingService.getAvailableSeats(showtimeId);
            System.out.println("Refreshed seats: " + seats.size());
            System.out.println("=== GUEST SEAT REFRESH API CALL END ===");
            
            return ResponseEntity.ok(seats);
        } catch (Exception e) {
            System.err.println("=== GUEST SEAT REFRESH API ERROR ===");
            System.err.println("Error: " + e.getMessage());
            e.printStackTrace();
            System.err.println("=== END GUEST SEAT REFRESH API ERROR ===");
            
            return ResponseEntity.status(500).body(Map.of(
                "error", "Failed to refresh seat availability",
                "message", e.getMessage(),
                "timestamp", System.currentTimeMillis()
            ));
        }
    }

    /**
     * Get seat details by ID
     * @param seatId Seat ID
     * @return Seat details
     */
    @GetMapping("/{seatId}")
    public ResponseEntity<?> getSeatDetails(@PathVariable Integer seatId) {
        try {
            System.out.println("=== GUEST SEAT DETAILS API CALL START ===");
            System.out.println("Seat ID: " + seatId);
            
            // This would require a seat service to get seat by ID
            // For now, return a basic response
            Map<String, Object> seatDetails = Map.of(
                "seatId", seatId,
                "message", "Seat details endpoint - implementation needed"
            );
            
            System.out.println("=== GUEST SEAT DETAILS API CALL END ===");
            return ResponseEntity.ok(seatDetails);
        } catch (Exception e) {
            System.err.println("=== GUEST SEAT DETAILS API ERROR ===");
            System.err.println("Error: " + e.getMessage());
            e.printStackTrace();
            System.err.println("=== END GUEST SEAT DETAILS API ERROR ===");
            
            return ResponseEntity.status(500).body(Map.of(
                "error", "Failed to get seat details",
                "message", e.getMessage(),
                "timestamp", System.currentTimeMillis()
            ));
        }
    }
}
