package com.flixmate.flixmate.api.controller;

import com.flixmate.flixmate.api.entity.Review;
import com.flixmate.flixmate.api.service.ReviewService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/reviews")
public class UserReviewController {

    @Autowired
    private ReviewService reviewService;

    @GetMapping("/user")
    public ResponseEntity<List<Review>> getUserReviews(@AuthenticationPrincipal UserDetails userDetails) {
        if (userDetails == null) {
            return ResponseEntity.status(401).build();
        }
        return ResponseEntity.ok(reviewService.getUserReviews(userDetails.getUsername()));
    }

    @PutMapping("/user/{reviewId}")
    public ResponseEntity<?> updateUserReview(@AuthenticationPrincipal UserDetails userDetails,
                                           @PathVariable Integer reviewId,
                                           @RequestBody ReviewRequest request) {
        try {
            boolean updated = reviewService.updateReview(
                userDetails.getUsername(), 
                reviewId, 
                request.getRating(), 
                request.getComment(),
                request.getTitle()
            );
            if (updated) {
                // Return the updated review data
                Review updatedReview = reviewService.getReviewById(reviewId);
                return ResponseEntity.ok(updatedReview);
            } else {
                return ResponseEntity.notFound().build();
            }
        } catch (Exception e) {
            return ResponseEntity.badRequest().body("Failed to update review: " + e.getMessage());
        }
    }

    @DeleteMapping("/user/{reviewId}")
    public ResponseEntity<?> deleteUserReview(@AuthenticationPrincipal UserDetails userDetails,
                                             @PathVariable Integer reviewId) {
        try {
            boolean deleted = reviewService.deleteReview(userDetails.getUsername(), reviewId);
            if (deleted) {
                return ResponseEntity.ok("Review deleted successfully");
            } else {
                return ResponseEntity.notFound().build();
            }
        } catch (Exception e) {
            return ResponseEntity.badRequest().body("Failed to delete review: " + e.getMessage());
        }
    }

    // Inner class for review request
    public static class ReviewRequest {
        private Integer rating;
        private String comment;
        private String title;
        private Boolean isVerifiedBooking;

        // Getters and setters
        public Integer getRating() { return rating; }
        public void setRating(Integer rating) { this.rating = rating; }
        
        public String getComment() { return comment; }
        public void setComment(String comment) { this.comment = comment; }
        
        public String getTitle() { return title; }
        public void setTitle(String title) { this.title = title; }
        
        public Boolean getIsVerifiedBooking() { return isVerifiedBooking; }
        public void setIsVerifiedBooking(Boolean isVerifiedBooking) { this.isVerifiedBooking = isVerifiedBooking; }
    }
}
