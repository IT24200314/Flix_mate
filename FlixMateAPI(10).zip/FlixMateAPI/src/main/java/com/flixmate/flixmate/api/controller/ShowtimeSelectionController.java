package com.flixmate.flixmate.api.controller;

import com.flixmate.flixmate.api.entity.ShowTime;
import com.flixmate.flixmate.api.entity.Movie;
import com.flixmate.flixmate.api.service.ShowTimeService;
import com.flixmate.flixmate.api.service.MovieService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * Controller for guest showtime selection functionality
 * Provides showtime viewing and selection capabilities for unregistered users
 */
@RestController
@RequestMapping("/api/guest/showtimes")
@CrossOrigin(origins = "*")
public class ShowtimeSelectionController {

    @Autowired
    private ShowTimeService showTimeService;

    @Autowired
    private MovieService movieService;

    /**
     * Get all showtimes for a specific movie
     * @param movieId Movie ID
     * @return List of showtimes for the movie
     */
    @GetMapping("/movie/{movieId}")
    public ResponseEntity<?> getMovieShowtimes(@PathVariable Integer movieId) {
        try {
            System.out.println("=== GUEST SHOWTIME SELECTION API CALL START ===");
            System.out.println("Movie ID: " + movieId);
            
            // Verify movie exists and is active
            Movie movie = movieService.getMovieById(movieId);
            if (movie == null || (movie.getIsActive() != null && !movie.getIsActive())) {
                System.out.println("Movie not found or inactive");
                System.out.println("=== GUEST SHOWTIME SELECTION API CALL END ===");
                return ResponseEntity.notFound().build();
            }

            List<ShowTime> showtimes = showTimeService.getShowTimesByMovie(movieId);
            System.out.println("Found showtimes: " + showtimes.size());
            
            // Filter future showtimes only
            LocalDateTime now = LocalDateTime.now();
            List<ShowTime> futureShowtimes = showtimes.stream()
                    .filter(showtime -> showtime.getStartTime().isAfter(now))
                    .collect(Collectors.toList());
            
            System.out.println("Future showtimes: " + futureShowtimes.size());
            System.out.println("=== GUEST SHOWTIME SELECTION API CALL END ===");
            
            return ResponseEntity.ok(futureShowtimes);
        } catch (Exception e) {
            System.err.println("=== GUEST SHOWTIME SELECTION API ERROR ===");
            System.err.println("Error: " + e.getMessage());
            e.printStackTrace();
            System.err.println("=== END GUEST SHOWTIME SELECTION API ERROR ===");
            
            return ResponseEntity.status(500).body(Map.of(
                "error", "Failed to fetch showtimes",
                "message", e.getMessage(),
                "timestamp", System.currentTimeMillis()
            ));
        }
    }

    /**
     * Get showtime details by ID
     * @param showtimeId Showtime ID
     * @return Showtime details
     */
    @GetMapping("/{showtimeId}")
    public ResponseEntity<?> getShowtimeDetails(@PathVariable Integer showtimeId) {
        try {
            System.out.println("=== GUEST SHOWTIME DETAILS API CALL START ===");
            System.out.println("Showtime ID: " + showtimeId);
            
            ShowTime showtime = showTimeService.getShowTimeById(showtimeId);
            if (showtime == null) {
                System.out.println("Showtime not found");
                System.out.println("=== GUEST SHOWTIME DETAILS API CALL END ===");
                return ResponseEntity.notFound().build();
            }

            // Check if showtime is in the future
            if (showtime.getStartTime().isBefore(LocalDateTime.now())) {
                System.out.println("Showtime is in the past");
                System.out.println("=== GUEST SHOWTIME DETAILS API CALL END ===");
                return ResponseEntity.badRequest().body(Map.of(
                    "error", "Showtime has already passed",
                    "message", "This showtime is no longer available"
                ));
            }

            System.out.println("Showtime found: " + showtime.getStartTime());
            System.out.println("=== GUEST SHOWTIME DETAILS API CALL END ===");
            
            return ResponseEntity.ok(showtime);
        } catch (Exception e) {
            System.err.println("=== GUEST SHOWTIME DETAILS API ERROR ===");
            System.err.println("Error: " + e.getMessage());
            e.printStackTrace();
            System.err.println("=== END GUEST SHOWTIME DETAILS API ERROR ===");
            
            return ResponseEntity.status(500).body(Map.of(
                "error", "Failed to get showtime details",
                "message", e.getMessage(),
                "timestamp", System.currentTimeMillis()
            ));
        }
    }

    /**
     * Get showtimes for a specific date
     * @param movieId Movie ID
     * @param date Date in YYYY-MM-DD format
     * @return List of showtimes for the date
     */
    @GetMapping("/movie/{movieId}/date/{date}")
    public ResponseEntity<?> getShowtimesByDate(@PathVariable Integer movieId, @PathVariable String date) {
        try {
            System.out.println("=== GUEST SHOWTIME BY DATE API CALL START ===");
            System.out.println("Movie ID: " + movieId + ", Date: " + date);
            
            // Verify movie exists and is active
            Movie movie = movieService.getMovieById(movieId);
            if (movie == null || (movie.getIsActive() != null && !movie.getIsActive())) {
                System.out.println("Movie not found or inactive");
                System.out.println("=== GUEST SHOWTIME BY DATE API CALL END ===");
                return ResponseEntity.notFound().build();
            }

            // Parse date
            LocalDateTime startOfDay = LocalDateTime.parse(date + "T00:00:00");
            LocalDateTime endOfDay = LocalDateTime.parse(date + "T23:59:59");

            List<ShowTime> allShowtimes = showTimeService.getShowTimesByMovie(movieId);
            List<ShowTime> showtimesForDate = allShowtimes.stream()
                    .filter(showtime -> showtime.getStartTime().isAfter(startOfDay) && 
                                       showtime.getStartTime().isBefore(endOfDay))
                    .collect(Collectors.toList());
            
            System.out.println("Showtimes for date: " + showtimesForDate.size());
            System.out.println("=== GUEST SHOWTIME BY DATE API CALL END ===");
            
            return ResponseEntity.ok(showtimesForDate);
        } catch (Exception e) {
            System.err.println("=== GUEST SHOWTIME BY DATE API ERROR ===");
            System.err.println("Error: " + e.getMessage());
            e.printStackTrace();
            System.err.println("=== END GUEST SHOWTIME BY DATE API ERROR ===");
            
            return ResponseEntity.status(500).body(Map.of(
                "error", "Failed to fetch showtimes for date",
                "message", e.getMessage(),
                "timestamp", System.currentTimeMillis()
            ));
        }
    }

    /**
     * Get available dates for a movie (next 7 days)
     * @param movieId Movie ID
     * @return List of available dates
     */
    @GetMapping("/movie/{movieId}/available-dates")
    public ResponseEntity<?> getAvailableDates(@PathVariable Integer movieId) {
        try {
            System.out.println("=== GUEST AVAILABLE DATES API CALL START ===");
            System.out.println("Movie ID: " + movieId);
            
            // Verify movie exists and is active
            Movie movie = movieService.getMovieById(movieId);
            if (movie == null || (movie.getIsActive() != null && !movie.getIsActive())) {
                System.out.println("Movie not found or inactive");
                System.out.println("=== GUEST AVAILABLE DATES API CALL END ===");
                return ResponseEntity.notFound().build();
            }

            List<ShowTime> allShowtimes = showTimeService.getShowTimesByMovie(movieId);
            LocalDateTime now = LocalDateTime.now();
            
            // Get unique dates for next 7 days
            List<String> availableDates = allShowtimes.stream()
                    .filter(showtime -> showtime.getStartTime().isAfter(now))
                    .map(showtime -> showtime.getStartTime().toLocalDate().toString())
                    .distinct()
                    .sorted()
                    .limit(7) // Next 7 days
                    .collect(Collectors.toList());
            
            System.out.println("Available dates: " + availableDates.size());
            System.out.println("=== GUEST AVAILABLE DATES API CALL END ===");
            
            return ResponseEntity.ok(availableDates);
        } catch (Exception e) {
            System.err.println("=== GUEST AVAILABLE DATES API ERROR ===");
            System.err.println("Error: " + e.getMessage());
            e.printStackTrace();
            System.err.println("=== END GUEST AVAILABLE DATES API ERROR ===");
            
            return ResponseEntity.status(500).body(Map.of(
                "error", "Failed to fetch available dates",
                "message", e.getMessage(),
                "timestamp", System.currentTimeMillis()
            ));
        }
    }

    /**
     * Get showtime summary with movie and hall information
     * @param showtimeId Showtime ID
     * @return Showtime summary with movie and hall details
     */
    @GetMapping("/{showtimeId}/summary")
    public ResponseEntity<?> getShowtimeSummary(@PathVariable Integer showtimeId) {
        try {
            System.out.println("=== GUEST SHOWTIME SUMMARY API CALL START ===");
            System.out.println("Showtime ID: " + showtimeId);
            
            ShowTime showtime = showTimeService.getShowTimeById(showtimeId);
            if (showtime == null) {
                System.out.println("Showtime not found");
                System.out.println("=== GUEST SHOWTIME SUMMARY API CALL END ===");
                return ResponseEntity.notFound().build();
            }

            // Check if showtime is in the future
            if (showtime.getStartTime().isBefore(LocalDateTime.now())) {
                System.out.println("Showtime is in the past");
                System.out.println("=== GUEST SHOWTIME SUMMARY API CALL END ===");
                return ResponseEntity.badRequest().body(Map.of(
                    "error", "Showtime has already passed",
                    "message", "This showtime is no longer available"
                ));
            }

            // Create summary response
            Map<String, Object> summary = Map.of(
                "showtimeId", showtime.getShowtimeId(),
                "startTime", showtime.getStartTime().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm")),
                "endTime", showtime.getEndTime().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm")),
                "price", showtime.getPrice(),
                "movie", Map.of(
                    "movieId", showtime.getMovie().getMovieId(),
                    "title", showtime.getMovie().getTitle(),
                    "duration", showtime.getMovie().getDuration(),
                    "rating", showtime.getMovie().getRating(),
                    "posterUrl", showtime.getMovie().getPosterUrl()
                ),
                "cinemaHall", Map.of(
                    "hallId", showtime.getCinemaHall().getHallId(),
                    "hallName", showtime.getCinemaHall().getHallName(),
                    "capacity", showtime.getCinemaHall().getCapacity()
                )
            );
            
            System.out.println("Showtime summary created successfully");
            System.out.println("=== GUEST SHOWTIME SUMMARY API CALL END ===");
            
            return ResponseEntity.ok(summary);
        } catch (Exception e) {
            System.err.println("=== GUEST SHOWTIME SUMMARY API ERROR ===");
            System.err.println("Error: " + e.getMessage());
            e.printStackTrace();
            System.err.println("=== END GUEST SHOWTIME SUMMARY API ERROR ===");
            
            return ResponseEntity.status(500).body(Map.of(
                "error", "Failed to get showtime summary",
                "message", e.getMessage(),
                "timestamp", System.currentTimeMillis()
            ));
        }
    }
}
