package com.flixmate.flixmate.api.monitoring;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.concurrent.atomic.AtomicLong;
import java.util.Map;
import java.util.HashMap;

/**
 * Custom health indicators for FlixMate API
 * Provides detailed health information about application components
 */
@Component
public class FlixMateHealthIndicator {
    
    @Autowired
    private DataSource dataSource;
    
    @Autowired
    private PerformanceMetrics performanceMetrics;
    
    private final AtomicLong lastHealthCheck = new AtomicLong(System.currentTimeMillis());
    private final AtomicLong consecutiveFailures = new AtomicLong(0);
    
    public Map<String, Object> getHealthStatus() {
        Map<String, Object> healthStatus = new HashMap<>();
        
        try {
            // Check database connectivity
            boolean dbHealthy = checkDatabaseHealth();
            
            if (dbHealthy) {
                healthStatus.put("status", "UP");
                healthStatus.put("database", "UP");
            } else {
                healthStatus.put("status", "DOWN");
                healthStatus.put("database", "DOWN");
                consecutiveFailures.incrementAndGet();
                healthStatus.put("consecutive_failures", consecutiveFailures.get());
                return healthStatus;
            }
            
            // Check application metrics
            healthStatus.put("active_bookings", performanceMetrics.getActiveBookings());
            healthStatus.put("total_revenue", performanceMetrics.getTotalRevenue());
            healthStatus.put("database_connections", performanceMetrics.getDatabaseConnections());
            healthStatus.put("last_health_check", lastHealthCheck.get());
            healthStatus.put("consecutive_failures", consecutiveFailures.get());
            
            // Check for performance issues
            if (performanceMetrics.getDatabaseConnections() > 8) {
                healthStatus.put("warning", "High database connection usage");
            }
            
            if (performanceMetrics.getActiveBookings() > 100) {
                healthStatus.put("warning", "High number of active bookings");
            }
            
            // Reset failure counter on successful check
            consecutiveFailures.set(0);
            lastHealthCheck.set(System.currentTimeMillis());
            
            return healthStatus;
            
        } catch (Exception e) {
            consecutiveFailures.incrementAndGet();
            healthStatus.put("status", "DOWN");
            healthStatus.put("error", e.getMessage());
            healthStatus.put("consecutive_failures", consecutiveFailures.get());
            return healthStatus;
        }
    }
    
    private boolean checkDatabaseHealth() {
        try (Connection connection = dataSource.getConnection()) {
            return connection.isValid(5); // 5 second timeout
        } catch (SQLException e) {
            return false;
        }
    }
    
    public long getConsecutiveFailures() {
        return consecutiveFailures.get();
    }
    
    public long getLastHealthCheck() {
        return lastHealthCheck.get();
    }
}
