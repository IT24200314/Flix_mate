-- FLIXMATE_2.0 Database Schema
-- This file contains the complete database schema for the FlixMate movie booking system

-- Create database (if not exists)
-- Note: This should be run manually in SQL Server Management Studio
CREATE DATABASE FLIXMATE_2_0;

--Use the database
USE FLIXMATE_2_0;

-- Drop existing tables if they exist (in reverse dependency order)
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[booking_seats]') AND type in (N'U'))
    DROP TABLE [dbo].[booking_seats];
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[payments]') AND type in (N'U'))
    DROP TABLE [dbo].[payments];
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[bookings]') AND type in (N'U'))
    DROP TABLE [dbo].[bookings];
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[reviews]') AND type in (N'U'))
    DROP TABLE [dbo].[reviews];
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[loyalty_points]') AND type in (N'U'))
    DROP TABLE [dbo].[loyalty_points];
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[reports]') AND type in (N'U'))
    DROP TABLE [dbo].[reports];
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[seats]') AND type in (N'U'))
    DROP TABLE [dbo].[seats];
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[showtimes]') AND type in (N'U'))
    DROP TABLE [dbo].[showtimes];
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[staff_schedules]') AND type in (N'U'))
    DROP TABLE [dbo].[staff_schedules];
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[cinema_halls]') AND type in (N'U'))
    DROP TABLE [dbo].[cinema_halls];
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[movies]') AND type in (N'U'))
    DROP TABLE [dbo].[movies];
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[users]') AND type in (N'U'))
    DROP TABLE [dbo].[users];
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[user_status]') AND type in (N'U'))
    DROP TABLE [dbo].[user_status];
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[discount_codes]') AND type in (N'U'))
    DROP TABLE [dbo].[discount_codes];
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[promotional_banners]') AND type in (N'U'))
    DROP TABLE [dbo].[promotional_banners];

-- Create User Status table
CREATE TABLE [dbo].[user_status] (
    [status_id] INT IDENTITY(1,1) PRIMARY KEY,
    [status_name] NVARCHAR(50) NOT NULL UNIQUE,
    [role] NVARCHAR(50) NOT NULL
);

-- Create Users table
CREATE TABLE [dbo].[users] (
    [user_id] INT IDENTITY(1,1) PRIMARY KEY,
    [user_name] NVARCHAR(100) NOT NULL,
    [password_hash] NVARCHAR(255) NOT NULL,
    [email] NVARCHAR(255) NOT NULL UNIQUE,
    [phone] NVARCHAR(20),
    [registration_date] NVARCHAR(50) NOT NULL,
    [last_login] NVARCHAR(50),
    [status_id] INT NOT NULL,
    FOREIGN KEY ([status_id]) REFERENCES [dbo].[user_status]([status_id])
);

-- Create Movies table
CREATE TABLE [dbo].[movies] (
    [movie_id] INT IDENTITY(1,1) PRIMARY KEY,
    [title] NVARCHAR(255) NOT NULL,
    [description] NVARCHAR(MAX),
    [release_year] INT,
    [genre] NVARCHAR(100),
    [duration] INT,
    [language] NVARCHAR(50),
    [director] NVARCHAR(255),
    [movie_cast] NVARCHAR(MAX),
    [trailer_url] NVARCHAR(500),
    [poster_url] NVARCHAR(500),
    [rating] NVARCHAR(10),
    [is_active] BIT DEFAULT 1,
    [created_date] DATETIME2,
    [updated_date] DATETIME2
);

-- Create Cinema Halls table
CREATE TABLE [dbo].[cinema_halls] (
    [hall_id] INT IDENTITY(1,1) PRIMARY KEY,
    [name] NVARCHAR(100) NOT NULL,
    [location] NVARCHAR(255),
    [capacity] INT NOT NULL
);

-- Create Seats table
CREATE TABLE [dbo].[seats] (
    [seat_id] INT IDENTITY(1,1) PRIMARY KEY,
    [row] NVARCHAR(10) NOT NULL,
    [number] INT NOT NULL,
    [status] NVARCHAR(20) NOT NULL,
    [hall_id] INT NOT NULL,
    FOREIGN KEY ([hall_id]) REFERENCES [dbo].[cinema_halls]([hall_id])
);

-- Create Showtimes table
CREATE TABLE [dbo].[showtimes] (
    [showtime_id] INT IDENTITY(1,1) PRIMARY KEY,
    [start_time] NVARCHAR(50) NOT NULL,
    [end_time] NVARCHAR(50),
    [price] DECIMAL(10,2) NOT NULL,
    [hall_id] INT NOT NULL,
    [movie_id] INT NOT NULL,
    FOREIGN KEY ([hall_id]) REFERENCES [dbo].[cinema_halls]([hall_id]),
    FOREIGN KEY ([movie_id]) REFERENCES [dbo].[movies]([movie_id])
);

-- Create Bookings table
CREATE TABLE [dbo].[bookings] (
    [booking_id] INT IDENTITY(1,1) PRIMARY KEY,
    [booking_date] NVARCHAR(50) NOT NULL,
    [total_seats] INT NOT NULL,
    [total_amount] DECIMAL(10,2) NOT NULL,
    [status] NVARCHAR(20) NOT NULL,
    [user_id] INT NOT NULL,
    [showtime_id] INT NOT NULL,
    FOREIGN KEY ([user_id]) REFERENCES [dbo].[users]([user_id]),
    FOREIGN KEY ([showtime_id]) REFERENCES [dbo].[showtimes]([showtime_id])
);

-- Create Booking Seats junction table
CREATE TABLE [dbo].[booking_seats] (
    [booking_id] INT NOT NULL,
    [seat_id] INT NOT NULL,
    PRIMARY KEY ([booking_id], [seat_id]),
    FOREIGN KEY ([booking_id]) REFERENCES [dbo].[bookings]([booking_id]),
    FOREIGN KEY ([seat_id]) REFERENCES [dbo].[seats]([seat_id])
);

-- Create Payments table
CREATE TABLE [dbo].[payments] (
    [payment_id] INT IDENTITY(1,1) PRIMARY KEY,
    [transaction_id] NVARCHAR(100) NOT NULL,
    [payment_date] NVARCHAR(50) NOT NULL,
    [payment_method] NVARCHAR(50) NOT NULL,
    [amount] DECIMAL(10,2) NOT NULL,
    [status] NVARCHAR(20) NOT NULL,
    [gateway_response] NVARCHAR(MAX),
    [failure_reason] NVARCHAR(500),
    [refund_amount] DECIMAL(10,2),
    [refund_date] NVARCHAR(50),
    [receipt_url] NVARCHAR(500),
    [booking_id] INT NOT NULL,
    FOREIGN KEY ([booking_id]) REFERENCES [dbo].[bookings]([booking_id])
);

-- Create Reviews table
CREATE TABLE [dbo].[reviews] (
    [review_id] INT IDENTITY(1,1) PRIMARY KEY,
    [rating] INT NOT NULL,
    [comment] NVARCHAR(MAX),
    [title] NVARCHAR(255),
    [is_verified_booking] BIT DEFAULT 0,
    [is_reported] BIT DEFAULT 0,
    [report_reason] NVARCHAR(500),
    [review_date] NVARCHAR(50) NOT NULL,
    [user_id] INT NOT NULL,
    [movie_id] INT NOT NULL,
    FOREIGN KEY ([user_id]) REFERENCES [dbo].[users]([user_id]),
    FOREIGN KEY ([movie_id]) REFERENCES [dbo].[movies]([movie_id])
);

-- Create Loyalty Points table
CREATE TABLE [dbo].[loyalty_points] (
    [points_id] INT IDENTITY(1,1) PRIMARY KEY,
    [user_id] INT NOT NULL,
    [points_balance] INT NOT NULL DEFAULT 0,
    [total_earned] INT NOT NULL DEFAULT 0,
    [total_redeemed] INT NOT NULL DEFAULT 0,
    [last_updated] DATETIME2 NOT NULL DEFAULT GETDATE(),
    FOREIGN KEY ([user_id]) REFERENCES [dbo].[users]([user_id])
);

-- Create Receipts table
CREATE TABLE [dbo].[receipts] (
    [receipt_id] INT IDENTITY(1,1) PRIMARY KEY,
    [receipt_number] NVARCHAR(100) NOT NULL UNIQUE,
    [receipt_date] NVARCHAR(50) NOT NULL,
    [movie_title] NVARCHAR(255) NOT NULL,
    [showtime_date] NVARCHAR(50) NOT NULL,
    [showtime_time] NVARCHAR(50) NOT NULL,
    [cinema_hall] NVARCHAR(100) NOT NULL,
    [seat_numbers] NVARCHAR(500) NOT NULL,
    [total_seats] INT NOT NULL,
    [total_amount] DECIMAL(10,2) NOT NULL,
    [payment_method] NVARCHAR(50) NOT NULL,
    [transaction_id] NVARCHAR(100),
    [user_name] NVARCHAR(255) NOT NULL,
    [user_email] NVARCHAR(255) NOT NULL,
    [booking_id] INT NOT NULL,
    [payment_id] INT NOT NULL,
    FOREIGN KEY ([booking_id]) REFERENCES [dbo].[bookings]([booking_id]),
    FOREIGN KEY ([payment_id]) REFERENCES [dbo].[payments]([payment_id])
);

-- Create Discount Codes table
CREATE TABLE [dbo].[discount_codes] (
    [code_id] INT IDENTITY(1,1) PRIMARY KEY,
    [code] NVARCHAR(50) NOT NULL UNIQUE,
    [description] NVARCHAR(255),
    [discount_type] NVARCHAR(20) NOT NULL,
    [discount_value] DECIMAL(10,2) NOT NULL,
    [min_purchase_amount] DECIMAL(10,2) DEFAULT 0.0,
    [max_discount_amount] DECIMAL(10,2),
    [usage_limit] INT,
    [used_count] INT NOT NULL DEFAULT 0,
    [valid_from] DATETIME2 NOT NULL,
    [valid_until] DATETIME2 NOT NULL,
    [is_active] BIT NOT NULL DEFAULT 1
);

-- Create Promotional Banners table
CREATE TABLE [dbo].[promotional_banners] (
    [banner_id] INT IDENTITY(1,1) PRIMARY KEY,
    [title] NVARCHAR(255) NOT NULL,
    [description] NVARCHAR(MAX),
    [image_url] NVARCHAR(500) NOT NULL,
    [target_url] NVARCHAR(500),
    [discount_code] NVARCHAR(50),
    [discount_percentage] DECIMAL(5,2),
    [start_date] NVARCHAR(50) NOT NULL,
    [end_date] NVARCHAR(50) NOT NULL,
    [is_active] BIT NOT NULL DEFAULT 1,
    [display_order] INT DEFAULT 0,
    [click_count] INT DEFAULT 0
);

-- Create Reports table
CREATE TABLE [dbo].[reports] (
    [report_id] INT IDENTITY(1,1) PRIMARY KEY,
    [type] NVARCHAR(50) NOT NULL,
    [data] NVARCHAR(MAX) NOT NULL,
    [generated_date] NVARCHAR(50) NOT NULL,
    [user_id] INT NOT NULL,
    FOREIGN KEY ([user_id]) REFERENCES [dbo].[users]([user_id])
);

-- Create Staff Schedules table
CREATE TABLE [dbo].[staff_schedules] (
    [schedule_id] INT IDENTITY(1,1) PRIMARY KEY,
    [staff_name] NVARCHAR(100) NOT NULL,
    [start_time] NVARCHAR(50) NOT NULL,
    [end_time] NVARCHAR(50) NOT NULL,
    [hall_id] INT NOT NULL,
    FOREIGN KEY ([hall_id]) REFERENCES [dbo].[cinema_halls]([hall_id])
);

-- Create indexes for better performance
CREATE INDEX [idx_user_status] ON [dbo].[bookings] ([user_id], [status]);
CREATE INDEX [idx_hall_status] ON [dbo].[seats] ([hall_id], [status]);
CREATE INDEX [idx_user_email] ON [dbo].[users] ([email]);
CREATE INDEX [idx_movie_title] ON [dbo].[movies] ([title]);
CREATE INDEX [idx_showtime_movie] ON [dbo].[showtimes] ([movie_id]);
CREATE INDEX [idx_showtime_hall] ON [dbo].[showtimes] ([hall_id]);
CREATE INDEX [idx_booking_date] ON [dbo].[bookings] ([booking_date]);
CREATE INDEX [idx_payment_status] ON [dbo].[payments] ([status]);
CREATE INDEX [idx_review_movie] ON [dbo].[reviews] ([movie_id]);
CREATE INDEX [idx_review_user] ON [dbo].[reviews] ([user_id]);

-- Insert default user statuses
INSERT INTO [dbo].[user_status] ([status_name], [role]) VALUES 
('Active', 'ROLE_USER'),
('Admin', 'ROLE_ADMIN'),
('Suspended', 'ROLE_USER'),
('Inactive', 'ROLE_USER');

-- Insert default admin user
-- Password: @Emuib0326 (hashed with BCrypt)
INSERT INTO [dbo].[users] ([user_name], [password_hash], [email], [phone], [registration_date], [status_id]) VALUES 
('SE', '$2a$10$N.zmdr9k7uOCQb376NoUnuTJ8iAt6Z5EHsM8lE9lBOsl7iKTVEFDi', 'admin@flixmate.com', '1234567890', '2024-01-01T00:00:00', 2);

-- Insert sample cinema halls
INSERT INTO [dbo].[cinema_halls] ([name], [location], [capacity]) VALUES 
('Hall A', 'Ground Floor', 100),
('Hall B', 'First Floor', 120),
('Hall C', 'Second Floor', 80),
('Hall D', 'Ground Floor', 150);

-- Insert sample movies
INSERT INTO [dbo].[movies] ([title], [description], [release_year], [genre], [duration], [language], [director], [movie_cast], [rating], [is_active], [created_date], [updated_date]) VALUES 
('The Avengers', 'Superhero action movie', 2012, 'Action', 143, 'English', 'Joss Whedon', 'Robert Downey Jr., Chris Evans, Scarlett Johansson', 'PG-13', 1, GETDATE(), GETDATE()),
('Inception', 'Mind-bending thriller', 2010, 'Sci-Fi', 148, 'English', 'Christopher Nolan', 'Leonardo DiCaprio, Marion Cotillard, Tom Hardy', 'PG-13', 1, GETDATE(), GETDATE()),
('The Dark Knight', 'Batman sequel', 2008, 'Action', 152, 'English', 'Christopher Nolan', 'Christian Bale, Heath Ledger, Aaron Eckhart', 'PG-13', 1, GETDATE(), GETDATE());

-- Insert sample seats for each hall
-- Hall A (100 seats: 10 rows x 10 seats)
INSERT INTO [dbo].[seats] ([row], [number], [status], [hall_id])
SELECT 
    CHAR(65 + (ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) - 1) / 10) as [row],
    ((ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) - 1) % 10) + 1 as [number],
    'AVAILABLE' as [status],
    1 as [hall_id]
FROM (SELECT TOP 100 ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) as n FROM sys.objects) t;

-- Hall B (120 seats: 12 rows x 10 seats)
INSERT INTO [dbo].[seats] ([row], [number], [status], [hall_id])
SELECT 
    CHAR(65 + (ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) - 1) / 10) as [row],
    ((ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) - 1) % 10) + 1 as [number],
    'AVAILABLE' as [status],
    2 as [hall_id]
FROM (SELECT TOP 120 ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) as n FROM sys.objects) t;

-- Hall C (80 seats: 8 rows x 10 seats)
INSERT INTO [dbo].[seats] ([row], [number], [status], [hall_id])
SELECT 
    CHAR(65 + (ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) - 1) / 10) as [row],
    ((ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) - 1) % 10) + 1 as [number],
    'AVAILABLE' as [status],
    3 as [hall_id]
FROM (SELECT TOP 80 ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) as n FROM sys.objects) t;

-- Hall D (150 seats: 15 rows x 10 seats)
INSERT INTO [dbo].[seats] ([row], [number], [status], [hall_id])
SELECT 
    CHAR(65 + (ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) - 1) / 10) as [row],
    ((ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) - 1) % 10) + 1 as [number],
    'AVAILABLE' as [status],
    4 as [hall_id]
FROM (SELECT TOP 150 ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) as n FROM sys.objects) t;

-- Insert sample showtimes
INSERT INTO [dbo].[showtimes] ([start_time], [end_time], [price], [hall_id], [movie_id]) VALUES 
('2024-12-20T10:00:00', '2024-12-20T12:30:00', 12.50, 1, 1),
('2024-12-20T14:00:00', '2024-12-20T16:30:00', 12.50, 1, 1),
('2024-12-20T18:00:00', '2024-12-20T20:30:00', 15.00, 1, 1),
('2024-12-20T10:30:00', '2024-12-20T13:00:00', 12.50, 2, 2),
('2024-12-20T15:00:00', '2024-12-20T17:30:00', 12.50, 2, 2),
('2024-12-20T19:00:00', '2024-12-20T21:30:00', 15.00, 2, 2);

-- Insert sample discount codes
INSERT INTO [dbo].[discount_codes] ([code], [description], [discount_type], [discount_value], [min_purchase_amount], [max_discount_amount], [usage_limit], [valid_from], [valid_until]) VALUES 
('WELCOME10', 'Welcome discount for new users', 'PERCENTAGE', 10.00, 20.00, 5.00, 100, GETDATE(), DATEADD(MONTH, 1, GETDATE())),
('SAVE5', 'Fixed amount discount', 'FIXED_AMOUNT', 5.00, 15.00, NULL, 50, GETDATE(), DATEADD(MONTH, 1, GETDATE()));

-- Insert sample promotional banners
INSERT INTO [dbo].[promotional_banners] ([title], [description], [image_url], [target_url], [discount_code], [discount_percentage], [start_date], [end_date], [display_order]) VALUES 
('New Year Special', 'Get 20% off on all movies this New Year', '/images/newyear-banner.jpg', '/movies', 'WELCOME10', 20.00, '2024-12-20T00:00:00', '2025-01-31T23:59:59', 1),
('Weekend Special', 'Special weekend pricing', '/images/weekend-banner.jpg', '/movies', NULL, 15.00, '2024-12-20T00:00:00', '2024-12-31T23:59:59', 2);

PRINT 'FLIXMATE_2.0 database schema created successfully!';
PRINT 'Default admin user created:';
PRINT 'Username: SE';
PRINT 'Password: @Emuib0326';
PRINT 'Email: admin@flixmate.com';
