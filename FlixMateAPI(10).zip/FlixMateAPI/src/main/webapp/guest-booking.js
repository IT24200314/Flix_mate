/**
 * Guest Booking JavaScript
 * Handles guest booking flow and authentication checks
 */

// Global variables
let isGuestUser = true;
let guestBookingData = null;

/**
 * Initialize guest booking functionality
 */
function initializeGuestBooking() {
    console.log('Initializing guest booking...');
    
    // Check if user is authenticated
    checkAuthenticationStatus();
    
    // Load any stored guest booking data
    loadGuestBookingData();
    
    // Set up event listeners
    setupGuestBookingEventListeners();
}

/**
 * Check authentication status
 */
async function checkAuthenticationStatus() {
    try {
        const response = await fetch('/api/guest/booking/auth-status');
        if (response.ok) {
            const authStatus = await response.json();
            isGuestUser = !authStatus.isAuthenticated;
            console.log('Authentication status:', authStatus);
            
            // Update UI based on authentication status
            updateUIForGuestStatus();
        }
    } catch (error) {
        console.error('Error checking authentication status:', error);
        // Assume guest user if check fails
        isGuestUser = true;
    }
}

/**
 * Update UI based on guest status
 */
function updateUIForGuestStatus() {
    if (isGuestUser) {
        // Add guest-specific UI elements
        addGuestNotifications();
        updateBookingButtons();
    }
}

/**
 * Add guest notifications
 */
function addGuestNotifications() {
    // Check if notification already exists
    if (document.getElementById('guest-notification')) {
        return;
    }
    
    const notification = document.createElement('div');
    notification.id = 'guest-notification';
    notification.className = 'alert alert-info alert-dismissible fade show';
    notification.innerHTML = `
        <i class="fas fa-info-circle me-2"></i>
        <strong>Guest User:</strong> You'll need to login to complete your booking.
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    `;
    
    // Insert at the top of the page
    const container = document.querySelector('.container');
    if (container) {
        container.insertBefore(notification, container.firstChild);
    }
}

/**
 * Update booking buttons for guest users
 */
function updateBookingButtons() {
    const proceedButtons = document.querySelectorAll('[onclick*="proceedToPayment"], [onclick*="proceedToBooking"]');
    
    proceedButtons.forEach(button => {
        // Update button text and behavior for guests
        if (button.textContent.includes('Payment') || button.textContent.includes('Booking')) {
            button.innerHTML = '<i class="fas fa-sign-in-alt me-2"></i>Login to Book';
            button.onclick = function() {
                handleGuestBookingRedirect();
            };
        }
    });
}

/**
 * Handle guest booking redirect
 */
function handleGuestBookingRedirect() {
    if (isGuestUser) {
        // Store current booking data
        storeGuestBookingData();
        
        // Redirect to login with booking context
        const currentUrl = window.location.href;
        const loginUrl = `/login.html?redirect=booking&returnUrl=${encodeURIComponent(currentUrl)}`;
        
        // Show confirmation dialog
        if (confirm('You need to login to complete your booking. Would you like to continue?')) {
            window.location.href = loginUrl;
        }
    }
}

/**
 * Store guest booking data
 */
function storeGuestBookingData() {
    try {
        // Collect current booking data
        const bookingData = collectCurrentBookingData();
        
        if (bookingData) {
            sessionStorage.setItem('guestBookingData', JSON.stringify(bookingData));
            console.log('Guest booking data stored:', bookingData);
        }
    } catch (error) {
        console.error('Error storing guest booking data:', error);
    }
}

/**
 * Collect current booking data from the page
 */
function collectCurrentBookingData() {
    const bookingData = {
        timestamp: new Date().toISOString(),
        source: window.location.pathname
    };
    
    // Collect data based on current page
    if (window.location.pathname.includes('seat-map.html')) {
        // Collect seat selection data
        const selectedSeats = [];
        document.querySelectorAll('.seat.selected').forEach(seat => {
            selectedSeats.push({
                seatId: parseInt(seat.dataset.seatId),
                row: seat.dataset.row,
                number: seat.dataset.number
            });
        });
        
        bookingData.selectedSeats = selectedSeats;
        bookingData.showtimeId = getShowtimeIdFromUrl();
        
    } else if (window.location.pathname.includes('showtime-selection.html')) {
        // Collect showtime selection data
        bookingData.movieId = getMovieIdFromUrl();
        bookingData.selectedDate = getSelectedDate();
        
    } else if (window.location.pathname.includes('movie-browsing.html')) {
        // Collect movie browsing data
        bookingData.searchFilters = getSearchFilters();
    }
    
    return bookingData;
}

/**
 * Load guest booking data from session storage
 */
function loadGuestBookingData() {
    try {
        const storedData = sessionStorage.getItem('guestBookingData');
        if (storedData) {
            guestBookingData = JSON.parse(storedData);
            console.log('Guest booking data loaded:', guestBookingData);
            
            // Restore booking state if applicable
            restoreBookingState();
        }
    } catch (error) {
        console.error('Error loading guest booking data:', error);
    }
}

/**
 * Restore booking state from stored data
 */
function restoreBookingState() {
    if (!guestBookingData) return;
    
    // Check if data is recent (within 1 hour)
    const dataTime = new Date(guestBookingData.timestamp);
    const now = new Date();
    const timeDiff = now - dataTime;
    
    if (timeDiff > 60 * 60 * 1000) { // 1 hour
        console.log('Guest booking data expired, clearing...');
        sessionStorage.removeItem('guestBookingData');
        return;
    }
    
    // Restore state based on current page
    if (window.location.pathname.includes('seat-map.html') && guestBookingData.selectedSeats) {
        restoreSeatSelection(guestBookingData.selectedSeats);
    }
}

/**
 * Restore seat selection
 */
function restoreSeatSelection(selectedSeats) {
    // Wait for seat map to load
    setTimeout(() => {
        selectedSeats.forEach(seatData => {
            const seatElement = document.querySelector(`[data-seat-id="${seatData.seatId}"]`);
            if (seatElement && !seatElement.classList.contains('occupied')) {
                seatElement.click(); // Trigger seat selection
            }
        });
    }, 1000);
}

/**
 * Setup event listeners for guest booking
 */
function setupGuestBookingEventListeners() {
    // Listen for booking-related clicks
    document.addEventListener('click', function(event) {
        const target = event.target;
        
        // Check if it's a booking-related button
        if (target.matches('[onclick*="proceedToPayment"], [onclick*="proceedToBooking"]')) {
            if (isGuestUser) {
                event.preventDefault();
                event.stopPropagation();
                handleGuestBookingRedirect();
            }
        }
    });
    
    // Listen for page unload to save booking data
    window.addEventListener('beforeunload', function() {
        if (isGuestUser) {
            storeGuestBookingData();
        }
    });
}

/**
 * Utility functions
 */

function getShowtimeIdFromUrl() {
    const urlParams = new URLSearchParams(window.location.search);
    return urlParams.get('showtimeId');
}

function getMovieIdFromUrl() {
    const urlParams = new URLSearchParams(window.location.search);
    return urlParams.get('movieId');
}

function getSelectedDate() {
    const activeDateBtn = document.querySelector('.date-btn.active');
    if (activeDateBtn) {
        return activeDateBtn.dataset.date;
    }
    return null;
}

function getSearchFilters() {
    return {
        searchTerm: document.getElementById('search-input')?.value || '',
        genre: document.getElementById('genre-filter')?.value || '',
        year: document.getElementById('year-filter')?.value || '',
        rating: document.getElementById('rating-filter')?.value || '',
        language: document.getElementById('language-filter')?.value || ''
    };
}

/**
 * Guest booking API functions
 */

/**
 * Validate guest booking request
 */
async function validateGuestBooking(showtimeId, selectedSeatIds) {
    try {
        const response = await fetch('/api/guest/booking/validate', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                showtimeId: showtimeId,
                selectedSeatIds: selectedSeatIds
            })
        });
        
        if (response.ok) {
            return await response.json();
        } else {
            const error = await response.json();
            throw new Error(error.message || 'Validation failed');
        }
    } catch (error) {
        console.error('Error validating guest booking:', error);
        throw error;
    }
}

/**
 * Get guest booking summary
 */
async function getGuestBookingSummary(showtimeId, seatIds) {
    try {
        const response = await fetch(`/api/guest/booking/summary?showtimeId=${showtimeId}&seatIds=${seatIds}`);
        
        if (response.ok) {
            return await response.json();
        } else {
            const error = await response.json();
            throw new Error(error.message || 'Failed to get booking summary');
        }
    } catch (error) {
        console.error('Error getting guest booking summary:', error);
        throw error;
    }
}

/**
 * Show guest login prompt
 */
function showGuestLoginPrompt() {
    const modal = document.createElement('div');
    modal.className = 'modal fade';
    modal.innerHTML = `
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">
                        <i class="fas fa-sign-in-alt me-2"></i>Login Required
                    </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <p>You need to login to complete your booking.</p>
                    <p>Your selected seats will be reserved for 10 minutes after login.</p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="button" class="btn btn-primary" onclick="redirectToLogin()">
                        <i class="fas fa-sign-in-alt me-2"></i>Login Now
                    </button>
                </div>
            </div>
        </div>
    `;
    
    document.body.appendChild(modal);
    const bootstrapModal = new bootstrap.Modal(modal);
    bootstrapModal.show();
    
    // Clean up modal after it's hidden
    modal.addEventListener('hidden.bs.modal', function() {
        document.body.removeChild(modal);
    });
}

/**
 * Redirect to login page
 */
function redirectToLogin() {
    const currentUrl = window.location.href;
    const loginUrl = `/login.html?redirect=booking&returnUrl=${encodeURIComponent(currentUrl)}`;
    window.location.href = loginUrl;
}

/**
 * Initialize when DOM is loaded
 */
document.addEventListener('DOMContentLoaded', function() {
    // Only initialize if this is a guest booking page
    if (window.location.pathname.includes('movie-browsing.html') || 
        window.location.pathname.includes('showtime-selection.html') || 
        window.location.pathname.includes('seat-map.html') ||
        window.location.pathname.includes('booking.html')) {
        initializeGuestBooking();
    }
});

// Export functions for global use
window.guestBooking = {
    initialize: initializeGuestBooking,
    validateBooking: validateGuestBooking,
    getBookingSummary: getGuestBookingSummary,
    showLoginPrompt: showGuestLoginPrompt,
    redirectToLogin: redirectToLogin,
    isGuestUser: () => isGuestUser,
    getBookingData: () => guestBookingData
};
