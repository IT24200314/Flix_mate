-- Add receipts table to existing database
-- Run this script to add the receipts table to your existing FlixMate database

-- Create Receipts table
CREATE TABLE [dbo].[receipts] (
    [receipt_id] INT IDENTITY(1,1) PRIMARY KEY,
    [receipt_number] NVARCHAR(100) NOT NULL UNIQUE,
    [receipt_date] NVARCHAR(50) NOT NULL,
    [movie_title] NVARCHAR(255) NOT NULL,
    [showtime_date] NVARCHAR(50) NOT NULL,
    [showtime_time] NVARCHAR(50) NOT NULL,
    [cinema_hall] NVARCHAR(100) NOT NULL,
    [seat_numbers] NVARCHAR(500) NOT NULL,
    [total_seats] INT NOT NULL,
    [total_amount] DECIMAL(10,2) NOT NULL,
    [payment_method] NVARCHAR(50) NOT NULL,
    [transaction_id] NVARCHAR(100),
    [user_name] NVARCHAR(255) NOT NULL,
    [user_email] NVARCHAR(255) NOT NULL,
    [booking_id] INT NOT NULL,
    [payment_id] INT NOT NULL,
    FOREIGN KEY ([booking_id]) REFERENCES [dbo].[bookings]([booking_id]),
    FOREIGN KEY ([payment_id]) REFERENCES [dbo].[payments]([payment_id])
);

-- Create indexes for better performance
CREATE INDEX [idx_receipts_user_email] ON [dbo].[receipts] ([user_email]);
CREATE INDEX [idx_receipts_receipt_number] ON [dbo].[receipts] ([receipt_number]);
CREATE INDEX [idx_receipts_booking_id] ON [dbo].[receipts] ([booking_id]);
CREATE INDEX [idx_receipts_payment_id] ON [dbo].[receipts] ([payment_id]);

PRINT 'Receipts table created successfully!';
