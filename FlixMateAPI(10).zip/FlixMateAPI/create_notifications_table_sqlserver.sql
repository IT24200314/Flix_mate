-- Create notifications table for admin notification system (SQL Server)
IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='notifications' AND xtype='U')
BEGIN
    CREATE TABLE notifications (
        notification_id BIGINT IDENTITY(1,1) PRIMARY KEY,
        type NVARCHAR(50) NOT NULL,
        title NVARCHAR(255) NOT NULL,
        message NVARCHAR(MAX) NOT NULL,
        is_read BIT NOT NULL DEFAULT 0,
        created_at DATETIME2 NOT NULL DEFAULT GETDATE(),
        read_at DATETIME2 NULL
    );
END

-- Create indexes for better performance
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'idx_notifications_created_at')
BEGIN
    CREATE INDEX idx_notifications_created_at ON notifications(created_at DESC);
END

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'idx_notifications_read')
BEGIN
    CREATE INDEX idx_notifications_read ON notifications(is_read);
END

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'idx_notifications_type')
BEGIN
    CREATE INDEX idx_notifications_type ON notifications(type);
END

-- Insert sample notifications for testing
INSERT INTO notifications (type, title, message, is_read, created_at) VALUES
('MOVIE_ADDED', 'New Movie Added', 'A new movie "The Matrix" has been added to the system.', 0, GETDATE()),
('SHOWTIME_ADDED', 'New Showtime Added', 'A new showtime for "The Matrix" has been scheduled for 2024-01-15 19:00.', 0, GETDATE()),
('STAFF_ADDED', 'New Staff Member Added', 'A new staff member "John Doe" has been added to the system.', 0, GETDATE()),
('STAFF_SCHEDULE_ADDED', 'New Staff Schedule Added', 'A new schedule has been assigned to staff member "John Doe" for Monday 9:00 AM.', 0, GETDATE()),
('ADMIN_ADDED', 'New Admin Added', 'A new admin user "admin2@example.com" has been added to the system.', 0, GETDATE());
