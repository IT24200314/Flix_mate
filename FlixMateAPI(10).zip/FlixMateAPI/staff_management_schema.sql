-- Staff Management Database Schema
-- This script creates the necessary tables for staff management functionality

-- Create staff table
CREATE TABLE IF NOT EXISTS staff (
    id BIGINT IDENTITY(1,1) PRIMARY KEY,
    first_name NVARCHAR(50) NOT NULL,
    last_name NVARCHAR(50) NOT NULL,
    email NVARCHAR(100) NOT NULL UNIQUE,
    phone NVARCHAR(20),
    position NVARCHAR(50) NOT NULL,
    assigned_hall NVARCHAR(50),
    address NVARCHAR(255),
    status NVARCHAR(20) NOT NULL DEFAULT 'Active',
    hire_date DATETIME2,
    created_at DATETIME2 DEFAULT GETDATE(),
    updated_at DATETIME2 DEFAULT GETDATE()
);

-- Create staff_schedules table
CREATE TABLE IF NOT EXISTS staff_schedules (
    id BIGINT IDENTITY(1,1) PRIMARY KEY,
    staff_id BIGINT NOT NULL,
    cinema_hall NVARCHAR(50) NOT NULL,
    start_date DATE NOT NULL,
    end_date DATE NOT NULL,
    start_time TIME NOT NULL,
    end_time TIME NOT NULL,
    notes NVARCHAR(500),
    status NVARCHAR(20) NOT NULL DEFAULT 'Scheduled',
    created_at DATETIME2 DEFAULT GETDATE(),
    updated_at DATETIME2 DEFAULT GETDATE(),
    FOREIGN KEY (staff_id) REFERENCES staff(id) ON DELETE CASCADE
);

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_staff_email ON staff(email);
CREATE INDEX IF NOT EXISTS idx_staff_position ON staff(position);
CREATE INDEX IF NOT EXISTS idx_staff_status ON staff(status);
CREATE INDEX IF NOT EXISTS idx_staff_assigned_hall ON staff(assigned_hall);

CREATE INDEX IF NOT EXISTS idx_schedules_staff_id ON staff_schedules(staff_id);
CREATE INDEX IF NOT EXISTS idx_schedules_cinema_hall ON staff_schedules(cinema_hall);
CREATE INDEX IF NOT EXISTS idx_schedules_start_date ON staff_schedules(start_date);
CREATE INDEX IF NOT EXISTS idx_schedules_end_date ON staff_schedules(end_date);
CREATE INDEX IF NOT EXISTS idx_schedules_status ON staff_schedules(status);

-- Insert sample staff data
INSERT INTO staff (first_name, last_name, email, phone, position, assigned_hall, address, status, hire_date) VALUES
('John', 'Smith', 'john.smith@flixmate.com', '+1-555-0123', 'Manager', 'Hall 1', '123 Main St, City, State', 'Active', '2023-01-15'),
('Sarah', 'Johnson', 'sarah.johnson@flixmate.com', '+1-555-0124', 'Ticket Seller', 'Hall 2', '456 Oak Ave, City, State', 'Active', '2023-02-20'),
('Mike', 'Wilson', 'mike.wilson@flixmate.com', '+1-555-0125', 'Usher', 'Hall 3', '789 Pine St, City, State', 'Active', '2023-03-10'),
('Emily', 'Davis', 'emily.davis@flixmate.com', '+1-555-0126', 'Concession Staff', 'Hall 1', '321 Elm St, City, State', 'Active', '2023-04-05'),
('David', 'Brown', 'david.brown@flixmate.com', '+1-555-0127', 'Security', 'Hall 2', '654 Maple Ave, City, State', 'Active', '2023-05-12'),
('Lisa', 'Garcia', 'lisa.garcia@flixmate.com', '+1-555-0128', 'Cleaner', 'Hall 3', '987 Cedar St, City, State', 'Active', '2023-06-18'),
('Robert', 'Martinez', 'robert.martinez@flixmate.com', '+1-555-0129', 'Ticket Seller', 'Hall 4', '147 Birch Rd, City, State', 'Active', '2023-07-22'),
('Jennifer', 'Anderson', 'jennifer.anderson@flixmate.com', '+1-555-0130', 'Usher', 'Hall 5', '258 Spruce Ln, City, State', 'Active', '2023-08-30');

-- Insert sample schedule data
INSERT INTO staff_schedules (staff_id, cinema_hall, start_date, end_date, start_time, end_time, notes, status) VALUES
(1, 'Hall 1', '2024-01-01', '2024-01-31', '09:00:00', '17:00:00', 'Manager shift for January', 'Scheduled'),
(2, 'Hall 2', '2024-01-01', '2024-01-31', '10:00:00', '18:00:00', 'Ticket seller for Hall 2', 'Scheduled'),
(3, 'Hall 3', '2024-01-01', '2024-01-31', '11:00:00', '19:00:00', 'Usher for Hall 3', 'Scheduled'),
(4, 'Hall 1', '2024-01-01', '2024-01-31', '12:00:00', '20:00:00', 'Concession staff for Hall 1', 'Scheduled'),
(5, 'Hall 2', '2024-01-01', '2024-01-31', '13:00:00', '21:00:00', 'Security for Hall 2', 'Scheduled'),
(6, 'Hall 3', '2024-01-01', '2024-01-31', '14:00:00', '22:00:00', 'Cleaner for Hall 3', 'Scheduled'),
(7, 'Hall 4', '2024-01-01', '2024-01-31', '15:00:00', '23:00:00', 'Ticket seller for Hall 4', 'Scheduled'),
(8, 'Hall 5', '2024-01-01', '2024-01-31', '16:00:00', '00:00:00', 'Usher for Hall 5', 'Scheduled');

-- Create a view for staff with their current schedules
CREATE VIEW IF NOT EXISTS staff_with_schedules AS
SELECT 
    s.id,
    s.first_name,
    s.last_name,
    s.email,
    s.phone,
    s.position,
    s.assigned_hall,
    s.status as staff_status,
    sch.cinema_hall,
    sch.start_date,
    sch.end_date,
    sch.start_time,
    sch.end_time,
    sch.status as schedule_status,
    sch.notes
FROM staff s
LEFT JOIN staff_schedules sch ON s.id = sch.staff_id
WHERE sch.status = 'Scheduled' 
  AND sch.start_date <= GETDATE() 
  AND sch.end_date >= GETDATE();

-- Create a view for today's staff assignments
CREATE VIEW IF NOT EXISTS today_staff_assignments AS
SELECT 
    s.first_name + ' ' + s.last_name as staff_name,
    s.position,
    sch.cinema_hall,
    sch.start_time,
    sch.end_time,
    sch.notes
FROM staff s
JOIN staff_schedules sch ON s.id = sch.staff_id
WHERE sch.status = 'Scheduled' 
  AND sch.start_date <= CAST(GETDATE() AS DATE)
  AND sch.end_date >= CAST(GETDATE() AS DATE)
ORDER BY sch.cinema_hall, sch.start_time;

-- Create a stored procedure to get staff statistics
CREATE PROCEDURE IF NOT EXISTS GetStaffStatistics
AS
BEGIN
    SELECT 
        (SELECT COUNT(*) FROM staff) as total_staff,
        (SELECT COUNT(*) FROM staff WHERE status = 'Active') as active_staff,
        (SELECT COUNT(*) FROM staff_schedules WHERE status = 'Scheduled') as scheduled_shifts,
        (SELECT COUNT(DISTINCT cinema_hall) FROM staff_schedules) as available_halls;
END;

-- Create a stored procedure to assign staff to cinema hall
CREATE PROCEDURE IF NOT EXISTS AssignStaffToHall
    @StaffId BIGINT,
    @CinemaHall NVARCHAR(50),
    @StartDate DATE,
    @EndDate DATE,
    @StartTime TIME,
    @EndTime TIME,
    @Notes NVARCHAR(500) = NULL
AS
BEGIN
    -- Check if staff exists
    IF NOT EXISTS (SELECT 1 FROM staff WHERE id = @StaffId)
    BEGIN
        RAISERROR('Staff member not found', 16, 1);
        RETURN;
    END
    
    -- Check for overlapping schedules
    IF EXISTS (
        SELECT 1 FROM staff_schedules 
        WHERE staff_id = @StaffId 
          AND status = 'Scheduled'
          AND ((start_date <= @StartDate AND end_date >= @StartDate) 
               OR (start_date <= @EndDate AND end_date >= @EndDate)
               OR (start_date >= @StartDate AND end_date <= @EndDate))
    )
    BEGIN
        RAISERROR('Staff member already has overlapping schedule', 16, 1);
        RETURN;
    END
    
    -- Insert new schedule
    INSERT INTO staff_schedules (staff_id, cinema_hall, start_date, end_date, start_time, end_time, notes, status)
    VALUES (@StaffId, @CinemaHall, @StartDate, @EndDate, @StartTime, @EndTime, @Notes, 'Scheduled');
    
    -- Update staff assigned hall
    UPDATE staff SET assigned_hall = @CinemaHall WHERE id = @StaffId;
END;

PRINT 'Staff management schema created successfully!';
PRINT 'Sample data inserted.';
PRINT 'Views and stored procedures created.';
