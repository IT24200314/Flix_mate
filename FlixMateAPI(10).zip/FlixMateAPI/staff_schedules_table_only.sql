-- Create Staff Schedules Table Only
-- Since staff table already exists, this script only creates the staff_schedules table

PRINT 'Creating Staff Schedules Table...';

-- ========================================
-- 1. CREATE STAFF_SCHEDULES TABLE
-- ========================================

-- Check if staff_schedules table exists, if not create it
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[staff_schedules]') AND type in (N'U'))
BEGIN
    PRINT 'Creating staff_schedules table...';
    CREATE TABLE [dbo].[staff_schedules] (
        [schedule_id] BIGINT IDENTITY(1,1) PRIMARY KEY,
        [staff_id] BIGINT NOT NULL,
        [staff_name] NVARCHAR(100) NOT NULL,
        [start_time] DATETIME2 NOT NULL,
        [end_time] DATETIME2 NOT NULL,
        [hall_id] INT NOT NULL,
        [shift_type] NVARCHAR(20) DEFAULT 'Regular',
        [status] NVARCHAR(20) DEFAULT 'Scheduled',
        [notes] NVARCHAR(500),
        [created_at] DATETIME2 DEFAULT GETDATE(),
        [updated_at] DATETIME2 DEFAULT GETDATE()
    );
    PRINT 'Staff_schedules table created successfully.';
END
ELSE
BEGIN
    PRINT 'Staff_schedules table already exists.';
END

-- ========================================
-- 2. ADD FOREIGN KEY CONSTRAINTS (SAFELY)
-- ========================================

-- Add foreign key constraint for staff_schedules.staff_id if it doesn't exist
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_staff_schedules_staff')
BEGIN
    BEGIN TRY
        ALTER TABLE [dbo].[staff_schedules] ADD CONSTRAINT FK_staff_schedules_staff 
        FOREIGN KEY ([staff_id]) REFERENCES [dbo].[staff]([id]) ON DELETE CASCADE;
        PRINT 'Added foreign key constraint FK_staff_schedules_staff.';
    END TRY
    BEGIN CATCH
        PRINT 'Warning: Could not add foreign key constraint FK_staff_schedules_staff. Some data may not be valid.';
    END CATCH
END

-- Add foreign key constraint for staff_schedules.hall_id if it doesn't exist
-- Note: This assumes cinema_halls table exists with hall_id column
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_staff_schedules_cinema_halls')
BEGIN
    BEGIN TRY
        ALTER TABLE [dbo].[staff_schedules] ADD CONSTRAINT FK_staff_schedules_cinema_halls 
        FOREIGN KEY ([hall_id]) REFERENCES [dbo].[cinema_halls]([hall_id]);
        PRINT 'Added foreign key constraint FK_staff_schedules_cinema_halls.';
    END TRY
    BEGIN CATCH
        PRINT 'Warning: Could not add foreign key constraint FK_staff_schedules_cinema_halls. Cinema_halls table may not exist.';
    END CATCH
END

-- ========================================
-- 3. INSERT SAMPLE SCHEDULE DATA
-- ========================================

-- Insert sample staff schedules if table is empty
IF NOT EXISTS (SELECT 1 FROM [dbo].[staff_schedules])
BEGIN
    PRINT 'Inserting sample schedule data...';
    
    INSERT INTO [dbo].[staff_schedules] ([staff_id], [staff_name], [start_time], [end_time], [hall_id], [shift_type], [status], [notes]) VALUES
    (1, 'John Doe', '2025-01-28 09:00:00', '2025-01-28 17:00:00', 1, 'Day', 'Scheduled', 'Manager shift - Hall A'),
    (2, 'Jane Smith', '2025-01-28 10:00:00', '2025-01-28 18:00:00', 1, 'Day', 'Scheduled', 'Ticket sales - Hall A'),
    (3, 'Mike Johnson', '2025-01-28 11:00:00', '2025-01-28 19:00:00', 2, 'Day', 'Scheduled', 'Concession - Hall B'),
    (4, 'Sarah Wilson', '2025-01-28 12:00:00', '2025-01-28 20:00:00', 2, 'Day', 'Scheduled', 'Usher - Hall B'),
    (5, 'David Brown', '2025-01-28 08:00:00', '2025-01-28 16:00:00', 3, 'Day', 'Scheduled', 'Security - Hall C'),
    (6, 'kamal Perera', '2025-01-28 14:00:00', '2025-01-28 22:00:00', 1, 'Evening', 'Scheduled', 'Usher - Hall A Evening');
    
    PRINT 'Sample schedule data inserted successfully.';
END
ELSE
BEGIN
    PRINT 'Staff_schedules table already contains data. Skipping sample data insertion.';
END

-- ========================================
-- 4. CREATE INDEXES FOR PERFORMANCE
-- ========================================

-- Create index on staff_schedules.staff_id for faster lookups
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_staff_schedules_staff_id')
BEGIN
    CREATE INDEX IX_staff_schedules_staff_id ON [dbo].[staff_schedules] ([staff_id]);
    PRINT 'Created index IX_staff_schedules_staff_id.';
END

-- Create index on staff_schedules.hall_id for faster lookups
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_staff_schedules_hall_id')
BEGIN
    CREATE INDEX IX_staff_schedules_hall_id ON [dbo].[staff_schedules] ([hall_id]);
    PRINT 'Created index IX_staff_schedules_hall_id.';
END

-- Create index on staff_schedules.start_time for faster date queries
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_staff_schedules_start_time')
BEGIN
    CREATE INDEX IX_staff_schedules_start_time ON [dbo].[staff_schedules] ([start_time]);
    PRINT 'Created index IX_staff_schedules_start_time.';
END

-- Create index on staff_schedules.status for faster status queries
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_staff_schedules_status')
BEGIN
    CREATE INDEX IX_staff_schedules_status ON [dbo].[staff_schedules] ([status]);
    PRINT 'Created index IX_staff_schedules_status.';
END

PRINT 'Staff Schedules Table Setup Completed Successfully!';
PRINT 'Table created: staff_schedules';
PRINT 'Foreign key constraints added with error handling';
PRINT 'Sample schedule data inserted';
PRINT 'Performance indexes created';