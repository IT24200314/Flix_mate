-- Fix Timestamp Format Issues
-- This script converts string timestamps to proper datetime format

USE FLIXMATE_2_0;
GO

-- Update timestamps that are stored as strings
UPDATE staff_schedules 
SET start_time = CASE 
    WHEN start_time LIKE '%T%' THEN 
        CONVERT(DATETIME2, REPLACE(start_time, 'T', ' '))
    ELSE start_time
END,
end_time = CASE 
    WHEN end_time LIKE '%T%' THEN 
        CONVERT(DATETIME2, REPLACE(end_time, 'T', ' '))
    ELSE end_time
END
WHERE start_time LIKE '%T%' OR end_time LIKE '%T%';

-- Verify the data after update
SELECT 
    schedule_id,
    staff_name,
    start_time,
    end_time,
    hall_id,
    shift_type,
    status
FROM staff_schedules
ORDER BY start_time;

PRINT 'Timestamp format fixed successfully!';
