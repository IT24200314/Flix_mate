-- Fix database constraints that are preventing application startup
USE FLIXMATE_2_0;

-- Drop the problematic unique constraint
IF EXISTS (SELECT * FROM sys.indexes WHERE name = 'UK_user_status_name' AND object_id = OBJECT_ID('user_status'))
BEGIN
    DROP INDEX UK_user_status_name ON user_status;
    PRINT 'Dropped UK_user_status_name constraint';
END

-- Check if the constraint exists as a unique constraint
IF EXISTS (SELECT * FROM sys.key_constraints WHERE name = 'UK_user_status_name')
BEGIN
    ALTER TABLE user_status DROP CONSTRAINT UK_user_status_name;
    PRINT 'Dropped UK_user_status_name unique constraint';
END

-- Check if the constraint exists as a check constraint
IF EXISTS (SELECT * FROM sys.check_constraints WHERE name = 'UK_user_status_name')
BEGIN
    ALTER TABLE user_status DROP CONSTRAINT UK_user_status_name;
    PRINT 'Dropped UK_user_status_name check constraint';
END

PRINT 'Database constraints fixed successfully!';

