-- Staff Database Update Script
-- Use this if you already have some tables and just need to update them
-- This script only adds missing columns and constraints

PRINT 'Starting Staff Database Update...';

-- ========================================
-- UPDATE STAFF TABLE
-- ========================================

-- Add missing columns to staff table
IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID('staff') AND name = 'assigned_hall_id')
BEGIN
    ALTER TABLE [dbo].[staff] ADD [assigned_hall_id] INT;
    PRINT 'Added assigned_hall_id column to staff table.';
END

IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID('staff') AND name = 'salary')
BEGIN
    ALTER TABLE [dbo].[staff] ADD [salary] DECIMAL(10,2);
    PRINT 'Added salary column to staff table.';
END

IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID('staff') AND name = 'emergency_contact_name')
BEGIN
    ALTER TABLE [dbo].[staff] ADD [emergency_contact_name] NVARCHAR(100);
    PRINT 'Added emergency_contact_name column to staff table.';
END

IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID('staff') AND name = 'emergency_contact_phone')
BEGIN
    ALTER TABLE [dbo].[staff] ADD [emergency_contact_phone] NVARCHAR(20);
    PRINT 'Added emergency_contact_phone column to staff table.';
END

IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID('staff') AND name = 'date_of_birth')
BEGIN
    ALTER TABLE [dbo].[staff] ADD [date_of_birth] DATE;
    PRINT 'Added date_of_birth column to staff table.';
END

IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID('staff') AND name = 'national_id')
BEGIN
    ALTER TABLE [dbo].[staff] ADD [national_id] NVARCHAR(20);
    PRINT 'Added national_id column to staff table.';
END

IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID('staff') AND name = 'created_at')
BEGIN
    ALTER TABLE [dbo].[staff] ADD [created_at] DATETIME2 DEFAULT GETDATE();
    PRINT 'Added created_at column to staff table.';
END

IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID('staff') AND name = 'updated_at')
BEGIN
    ALTER TABLE [dbo].[staff] ADD [updated_at] DATETIME2 DEFAULT GETDATE();
    PRINT 'Added updated_at column to staff table.';
END

-- ========================================
-- UPDATE STAFF_SCHEDULES TABLE
-- ========================================

-- Add missing columns to staff_schedules table
IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID('staff_schedules') AND name = 'staff_id')
BEGIN
    ALTER TABLE [dbo].[staff_schedules] ADD [staff_id] BIGINT;
    PRINT 'Added staff_id column to staff_schedules table.';
END

IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID('staff_schedules') AND name = 'shift_type')
BEGIN
    ALTER TABLE [dbo].[staff_schedules] ADD [shift_type] NVARCHAR(20) DEFAULT 'Regular';
    PRINT 'Added shift_type column to staff_schedules table.';
END

IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID('staff_schedules') AND name = 'status')
BEGIN
    ALTER TABLE [dbo].[staff_schedules] ADD [status] NVARCHAR(20) DEFAULT 'Scheduled';
    PRINT 'Added status column to staff_schedules table.';
END

IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID('staff_schedules') AND name = 'notes')
BEGIN
    ALTER TABLE [dbo].[staff_schedules] ADD [notes] NVARCHAR(500);
    PRINT 'Added notes column to staff_schedules table.';
END

IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID('staff_schedules') AND name = 'created_at')
BEGIN
    ALTER TABLE [dbo].[staff_schedules] ADD [created_at] DATETIME2 DEFAULT GETDATE();
    PRINT 'Added created_at column to staff_schedules table.';
END

IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID('staff_schedules') AND name = 'updated_at')
BEGIN
    ALTER TABLE [dbo].[staff_schedules] ADD [updated_at] DATETIME2 DEFAULT GETDATE();
    PRINT 'Added updated_at column to staff_schedules table.';
END

-- ========================================
-- ADD FOREIGN KEY CONSTRAINTS
-- ========================================

-- Add foreign key constraint for staff.assigned_hall_id
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_staff_cinema_halls')
BEGIN
    ALTER TABLE [dbo].[staff] ADD CONSTRAINT FK_staff_cinema_halls 
    FOREIGN KEY ([assigned_hall_id]) REFERENCES [dbo].[cinema_halls]([hall_id]);
    PRINT 'Added foreign key constraint FK_staff_cinema_halls.';
END

-- Add foreign key constraint for staff_schedules.staff_id
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_staff_schedules_staff')
BEGIN
    ALTER TABLE [dbo].[staff_schedules] ADD CONSTRAINT FK_staff_schedules_staff 
    FOREIGN KEY ([staff_id]) REFERENCES [dbo].[staff]([id]) ON DELETE CASCADE;
    PRINT 'Added foreign key constraint FK_staff_schedules_staff.';
END

-- Add foreign key constraint for staff_schedules.hall_id
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_staff_schedules_cinema_halls')
BEGIN
    ALTER TABLE [dbo].[staff_schedules] ADD CONSTRAINT FK_staff_schedules_cinema_halls 
    FOREIGN KEY ([hall_id]) REFERENCES [dbo].[cinema_halls]([hall_id]);
    PRINT 'Added foreign key constraint FK_staff_schedules_cinema_halls.';
END

-- ========================================
-- CREATE INDEXES
-- ========================================

-- Create indexes for staff table
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_staff_email' AND object_id = OBJECT_ID('staff'))
BEGIN
    CREATE INDEX IX_staff_email ON [dbo].[staff]([email]);
    PRINT 'Created index IX_staff_email.';
END

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_staff_position' AND object_id = OBJECT_ID('staff'))
BEGIN
    CREATE INDEX IX_staff_position ON [dbo].[staff]([position]);
    PRINT 'Created index IX_staff_position.';
END

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_staff_status' AND object_id = OBJECT_ID('staff'))
BEGIN
    CREATE INDEX IX_staff_status ON [dbo].[staff]([status]);
    PRINT 'Created index IX_staff_status.';
END

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_staff_assigned_hall_id' AND object_id = OBJECT_ID('staff'))
BEGIN
    CREATE INDEX IX_staff_assigned_hall_id ON [dbo].[staff]([assigned_hall_id]);
    PRINT 'Created index IX_staff_assigned_hall_id.';
END

-- Create indexes for staff_schedules table
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_staff_schedules_staff_id' AND object_id = OBJECT_ID('staff_schedules'))
BEGIN
    CREATE INDEX IX_staff_schedules_staff_id ON [dbo].[staff_schedules]([staff_id]);
    PRINT 'Created index IX_staff_schedules_staff_id.';
END

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_staff_schedules_hall_id' AND object_id = OBJECT_ID('staff_schedules'))
BEGIN
    CREATE INDEX IX_staff_schedules_hall_id ON [dbo].[staff_schedules]([hall_id]);
    PRINT 'Created index IX_staff_schedules_hall_id.';
END

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_staff_schedules_date' AND object_id = OBJECT_ID('staff_schedules'))
BEGIN
    CREATE INDEX IX_staff_schedules_date ON [dbo].[staff_schedules]([start_time]);
    PRINT 'Created index IX_staff_schedules_date.';
END

PRINT '';
PRINT 'Staff Database Update Complete!';
PRINT 'All missing columns and constraints have been added.';
