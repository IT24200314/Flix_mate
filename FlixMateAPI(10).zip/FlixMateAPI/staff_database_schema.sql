-- Staff Management Database Schema
-- This script modifies existing tables to add staff management functionality
-- Aligns with existing cinema_halls table structure

-- Check if staff table exists, if not create it
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[staff]') AND type in (N'U'))
BEGIN
    CREATE TABLE [dbo].[staff] (
        [id] BIGINT IDENTITY(1,1) PRIMARY KEY,
        [first_name] NVARCHAR(50) NOT NULL,
        [last_name] NVARCHAR(50) NOT NULL,
        [email] NVARCHAR(100) NOT NULL UNIQUE,
        [phone] NVARCHAR(20),
        [position] NVARCHAR(50) NOT NULL,
        [assigned_hall_id] INT,  -- Foreign key to cinema_halls.hall_id
        [address] NVARCHAR(500),
        [status] NVARCHAR(20) NOT NULL DEFAULT 'Active',
        [hire_date] DATETIME2 DEFAULT GETDATE(),
        [salary] DECIMAL(10,2),
        [emergency_contact_name] NVARCHAR(100),
        [emergency_contact_phone] NVARCHAR(20),
        [date_of_birth] DATE,
        [national_id] NVARCHAR(20),
        [created_at] DATETIME2 DEFAULT GETDATE(),
        [updated_at] DATETIME2 DEFAULT GETDATE(),
        FOREIGN KEY ([assigned_hall_id]) REFERENCES [dbo].[cinema_halls]([hall_id])
    );
END
ELSE
BEGIN
    -- Add new columns to existing staff table if they don't exist
    IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID('staff') AND name = 'assigned_hall_id')
        ALTER TABLE [dbo].[staff] ADD [assigned_hall_id] INT;
    
    IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID('staff') AND name = 'salary')
        ALTER TABLE [dbo].[staff] ADD [salary] DECIMAL(10,2);
    
    IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID('staff') AND name = 'emergency_contact_name')
        ALTER TABLE [dbo].[staff] ADD [emergency_contact_name] NVARCHAR(100);
    
    IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID('staff') AND name = 'emergency_contact_phone')
        ALTER TABLE [dbo].[staff] ADD [emergency_contact_phone] NVARCHAR(20);
    
    IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID('staff') AND name = 'date_of_birth')
        ALTER TABLE [dbo].[staff] ADD [date_of_birth] DATE;
    
    IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID('staff') AND name = 'national_id')
        ALTER TABLE [dbo].[staff] ADD [national_id] NVARCHAR(20);
    
    -- Add foreign key constraint if it doesn't exist
    IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_staff_cinema_halls')
        ALTER TABLE [dbo].[staff] ADD CONSTRAINT FK_staff_cinema_halls 
        FOREIGN KEY ([assigned_hall_id]) REFERENCES [dbo].[cinema_halls]([hall_id]);
END

-- Check if staff_schedules table exists, if not create it
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[staff_schedules]') AND type in (N'U'))
BEGIN
    CREATE TABLE [dbo].[staff_schedules] (
        [schedule_id] BIGINT IDENTITY(1,1) PRIMARY KEY,
        [staff_id] BIGINT NOT NULL,
        [staff_name] NVARCHAR(100) NOT NULL,
        [start_time] DATETIME2 NOT NULL,
        [end_time] DATETIME2 NOT NULL,
        [hall_id] INT NOT NULL,  -- Foreign key to cinema_halls.hall_id
        [shift_type] NVARCHAR(20) DEFAULT 'Regular',
        [status] NVARCHAR(20) DEFAULT 'Scheduled',
        [notes] NVARCHAR(500),
        [created_at] DATETIME2 DEFAULT GETDATE(),
        [updated_at] DATETIME2 DEFAULT GETDATE(),
        FOREIGN KEY ([staff_id]) REFERENCES [dbo].[staff]([id]) ON DELETE CASCADE,
        FOREIGN KEY ([hall_id]) REFERENCES [dbo].[cinema_halls]([hall_id])
    );
END

-- Create indexes for better performance (only if they don't exist)
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_staff_email' AND object_id = OBJECT_ID('staff'))
    CREATE INDEX IX_staff_email ON [dbo].[staff]([email]);

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_staff_position' AND object_id = OBJECT_ID('staff'))
    CREATE INDEX IX_staff_position ON [dbo].[staff]([position]);

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_staff_status' AND object_id = OBJECT_ID('staff'))
    CREATE INDEX IX_staff_status ON [dbo].[staff]([status]);

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_staff_schedules_staff_id' AND object_id = OBJECT_ID('staff_schedules'))
    CREATE INDEX IX_staff_schedules_staff_id ON [dbo].[staff_schedules]([staff_id]);

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_staff_schedules_date' AND object_id = OBJECT_ID('staff_schedules'))
    CREATE INDEX IX_staff_schedules_date ON [dbo].[staff_schedules]([start_time]);

-- Insert sample staff data (only if table is empty)
IF NOT EXISTS (SELECT 1 FROM [dbo].[staff])
BEGIN
    INSERT INTO [dbo].[staff] (
        [first_name], [last_name], [email], [phone], [position], [assigned_hall_id], [address], [status], [hire_date], [salary]
    ) VALUES 
    ('John', 'Doe', 'john.doe@flixmate.com', '+1-555-0101', 'Manager', 1, '123 Main St, City, State', 'Active', '2023-01-15', 50000.00),
    ('Jane', 'Smith', 'jane.smith@flixmate.com', '+1-555-0102', 'Ticket Seller', 1, '456 Oak Ave, City, State', 'Active', '2023-02-01', 35000.00),
    ('Mike', 'Johnson', 'mike.johnson@flixmate.com', '+1-555-0103', 'Concession Staff', 2, '789 Pine St, City, State', 'Active', '2023-02-15', 32000.00),
    ('Sarah', 'Wilson', 'sarah.wilson@flixmate.com', '+1-555-0104', 'Usher', 2, '321 Elm St, City, State', 'Active', '2023-03-01', 30000.00),
    ('David', 'Brown', 'david.brown@flixmate.com', '+1-555-0105', 'Security', 3, '654 Maple Dr, City, State', 'Active', '2023-03-15', 40000.00);
END

-- Insert sample schedule data (only if table is empty)
IF NOT EXISTS (SELECT 1 FROM [dbo].[staff_schedules])
BEGIN
    INSERT INTO [dbo].[staff_schedules] (
        [staff_id], [staff_name], [start_time], [end_time], [hall_id], [shift_type], [status]
    ) VALUES 
    (1, 'John Doe', '2025-09-28 08:00:00', '2025-09-28 16:00:00', 1, 'Regular', 'Scheduled'),
    (2, 'Jane Smith', '2025-09-28 14:00:00', '2025-09-28 22:00:00', 1, 'Regular', 'Scheduled'),
    (3, 'Mike Johnson', '2025-09-28 10:00:00', '2025-09-28 18:00:00', 2, 'Regular', 'Scheduled'),
    (4, 'Sarah Wilson', '2025-09-28 16:00:00', '2025-09-28 24:00:00', 2, 'Regular', 'Scheduled'),
    (5, 'David Brown', '2025-09-28 20:00:00', '2025-09-29 04:00:00', 3, 'Night', 'Scheduled');
END

-- Create a view for staff with their schedules
CREATE VIEW [dbo].[staff_with_schedules] AS
SELECT 
    s.id,
    s.first_name,
    s.last_name,
    s.email,
    s.phone,
    s.position,
    s.assigned_hall,
    s.status,
    s.hire_date,
    s.salary,
    COUNT(sch.schedule_id) as total_schedules,
    MAX(sch.start_time) as last_schedule
FROM [dbo].[staff] s
LEFT JOIN [dbo].[staff_schedules] sch ON s.id = sch.staff_id
GROUP BY s.id, s.first_name, s.last_name, s.email, s.phone, s.position, s.assigned_hall, s.status, s.hire_date, s.salary;

PRINT 'Staff management database schema created successfully!';
PRINT 'Tables created: staff, staff_schedules';
PRINT 'Sample data inserted for testing';
