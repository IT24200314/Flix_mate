-- Complete Staff Database Schema
-- This script handles both new installations and updates to existing databases
-- Aligns with existing cinema_halls table structure

PRINT 'Starting Staff Database Schema Setup...';

-- ========================================
-- 1. CREATE/UPDATE STAFF TABLE
-- ========================================

-- Check if staff table exists, if not create it
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[staff]') AND type in (N'U'))
BEGIN
    PRINT 'Creating staff table...';
    CREATE TABLE [dbo].[staff] (
        [id] BIGINT IDENTITY(1,1) PRIMARY KEY,
        [first_name] NVARCHAR(50) NOT NULL,
        [last_name] NVARCHAR(50) NOT NULL,
        [email] NVARCHAR(100) NOT NULL UNIQUE,
        [phone] NVARCHAR(20),
        [position] NVARCHAR(50) NOT NULL,
        [assigned_hall_id] INT,
        [address] NVARCHAR(500),
        [status] NVARCHAR(20) NOT NULL DEFAULT 'Active',
        [hire_date] DATETIME2 DEFAULT GETDATE(),
        [salary] DECIMAL(10,2),
        [emergency_contact_name] NVARCHAR(100),
        [emergency_contact_phone] NVARCHAR(20),
        [date_of_birth] DATE,
        [national_id] NVARCHAR(20),
        [created_at] DATETIME2 DEFAULT GETDATE(),
        [updated_at] DATETIME2 DEFAULT GETDATE()
    );
    PRINT 'Staff table created successfully.';
END
ELSE
BEGIN
    PRINT 'Staff table already exists. Checking for missing columns...';
    
    -- Add new columns to existing staff table if they don't exist
    IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID('staff') AND name = 'assigned_hall_id')
    BEGIN
        ALTER TABLE [dbo].[staff] ADD [assigned_hall_id] INT;
        PRINT 'Added assigned_hall_id column.';
    END
    
    IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID('staff') AND name = 'salary')
    BEGIN
        ALTER TABLE [dbo].[staff] ADD [salary] DECIMAL(10,2);
        PRINT 'Added salary column.';
    END
    
    IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID('staff') AND name = 'emergency_contact_name')
    BEGIN
        ALTER TABLE [dbo].[staff] ADD [emergency_contact_name] NVARCHAR(100);
        PRINT 'Added emergency_contact_name column.';
    END
    
    IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID('staff') AND name = 'emergency_contact_phone')
    BEGIN
        ALTER TABLE [dbo].[staff] ADD [emergency_contact_phone] NVARCHAR(20);
        PRINT 'Added emergency_contact_phone column.';
    END
    
    IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID('staff') AND name = 'date_of_birth')
    BEGIN
        ALTER TABLE [dbo].[staff] ADD [date_of_birth] DATE;
        PRINT 'Added date_of_birth column.';
    END
    
    IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID('staff') AND name = 'national_id')
    BEGIN
        ALTER TABLE [dbo].[staff] ADD [national_id] NVARCHAR(20);
        PRINT 'Added national_id column.';
    END
    
    IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID('staff') AND name = 'created_at')
    BEGIN
        ALTER TABLE [dbo].[staff] ADD [created_at] DATETIME2 DEFAULT GETDATE();
        PRINT 'Added created_at column.';
    END
    
    IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID('staff') AND name = 'updated_at')
    BEGIN
        ALTER TABLE [dbo].[staff] ADD [updated_at] DATETIME2 DEFAULT GETDATE();
        PRINT 'Added updated_at column.';
    END
END

-- ========================================
-- 2. CREATE/UPDATE STAFF_SCHEDULES TABLE
-- ========================================

-- Check if staff_schedules table exists, if not create it
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[staff_schedules]') AND type in (N'U'))
BEGIN
    PRINT 'Creating staff_schedules table...';
    CREATE TABLE [dbo].[staff_schedules] (
        [schedule_id] BIGINT IDENTITY(1,1) PRIMARY KEY,
        [staff_id] BIGINT NOT NULL,
        [staff_name] NVARCHAR(100) NOT NULL,
        [start_time] DATETIME2 NOT NULL,
        [end_time] DATETIME2 NOT NULL,
        [hall_id] INT NOT NULL,
        [shift_type] NVARCHAR(20) DEFAULT 'Regular',
        [status] NVARCHAR(20) DEFAULT 'Scheduled',
        [notes] NVARCHAR(500),
        [created_at] DATETIME2 DEFAULT GETDATE(),
        [updated_at] DATETIME2 DEFAULT GETDATE()
    );
    PRINT 'Staff_schedules table created successfully.';
END
ELSE
BEGIN
    PRINT 'Staff_schedules table already exists. Checking for missing columns...';
    
    -- Add new columns to existing staff_schedules table if they don't exist
    IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID('staff_schedules') AND name = 'staff_id')
    BEGIN
        ALTER TABLE [dbo].[staff_schedules] ADD [staff_id] BIGINT;
        PRINT 'Added staff_id column.';
    END
    
    IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID('staff_schedules') AND name = 'shift_type')
    BEGIN
        ALTER TABLE [dbo].[staff_schedules] ADD [shift_type] NVARCHAR(20) DEFAULT 'Regular';
        PRINT 'Added shift_type column.';
    END
    
    IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID('staff_schedules') AND name = 'status')
    BEGIN
        ALTER TABLE [dbo].[staff_schedules] ADD [status] NVARCHAR(20) DEFAULT 'Scheduled';
        PRINT 'Added status column.';
    END
    
    IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID('staff_schedules') AND name = 'notes')
    BEGIN
        ALTER TABLE [dbo].[staff_schedules] ADD [notes] NVARCHAR(500);
        PRINT 'Added notes column.';
    END
    
    IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID('staff_schedules') AND name = 'created_at')
    BEGIN
        ALTER TABLE [dbo].[staff_schedules] ADD [created_at] DATETIME2 DEFAULT GETDATE();
        PRINT 'Added created_at column.';
    END
    
    IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID('staff_schedules') AND name = 'updated_at')
    BEGIN
        ALTER TABLE [dbo].[staff_schedules] ADD [updated_at] DATETIME2 DEFAULT GETDATE();
        PRINT 'Added updated_at column.';
    END
END

-- ========================================
-- 3. ADD FOREIGN KEY CONSTRAINTS
-- ========================================

-- Add foreign key constraint for staff.assigned_hall_id if it doesn't exist
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_staff_cinema_halls')
BEGIN
    ALTER TABLE [dbo].[staff] ADD CONSTRAINT FK_staff_cinema_halls 
    FOREIGN KEY ([assigned_hall_id]) REFERENCES [dbo].[cinema_halls]([hall_id]);
    PRINT 'Added foreign key constraint FK_staff_cinema_halls.';
END

-- Add foreign key constraint for staff_schedules.staff_id if it doesn't exist
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_staff_schedules_staff')
BEGIN
    ALTER TABLE [dbo].[staff_schedules] ADD CONSTRAINT FK_staff_schedules_staff 
    FOREIGN KEY ([staff_id]) REFERENCES [dbo].[staff]([id]) ON DELETE CASCADE;
    PRINT 'Added foreign key constraint FK_staff_schedules_staff.';
END

-- Add foreign key constraint for staff_schedules.hall_id if it doesn't exist
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_staff_schedules_cinema_halls')
BEGIN
    ALTER TABLE [dbo].[staff_schedules] ADD CONSTRAINT FK_staff_schedules_cinema_halls 
    FOREIGN KEY ([hall_id]) REFERENCES [dbo].[cinema_halls]([hall_id]);
    PRINT 'Added foreign key constraint FK_staff_schedules_cinema_halls.';
END

-- ========================================
-- 4. CREATE INDEXES
-- ========================================

-- Create indexes for staff table (only if they don't exist)
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_staff_email' AND object_id = OBJECT_ID('staff'))
BEGIN
    CREATE INDEX IX_staff_email ON [dbo].[staff]([email]);
    PRINT 'Created index IX_staff_email.';
END

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_staff_position' AND object_id = OBJECT_ID('staff'))
BEGIN
    CREATE INDEX IX_staff_position ON [dbo].[staff]([position]);
    PRINT 'Created index IX_staff_position.';
END

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_staff_status' AND object_id = OBJECT_ID('staff'))
BEGIN
    CREATE INDEX IX_staff_status ON [dbo].[staff]([status]);
    PRINT 'Created index IX_staff_status.';
END

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_staff_assigned_hall_id' AND object_id = OBJECT_ID('staff'))
BEGIN
    CREATE INDEX IX_staff_assigned_hall_id ON [dbo].[staff]([assigned_hall_id]);
    PRINT 'Created index IX_staff_assigned_hall_id.';
END

-- Create indexes for staff_schedules table (only if they don't exist)
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_staff_schedules_staff_id' AND object_id = OBJECT_ID('staff_schedules'))
BEGIN
    CREATE INDEX IX_staff_schedules_staff_id ON [dbo].[staff_schedules]([staff_id]);
    PRINT 'Created index IX_staff_schedules_staff_id.';
END

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_staff_schedules_hall_id' AND object_id = OBJECT_ID('staff_schedules'))
BEGIN
    CREATE INDEX IX_staff_schedules_hall_id ON [dbo].[staff_schedules]([hall_id]);
    PRINT 'Created index IX_staff_schedules_hall_id.';
END

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_staff_schedules_date' AND object_id = OBJECT_ID('staff_schedules'))
BEGIN
    CREATE INDEX IX_staff_schedules_date ON [dbo].[staff_schedules]([start_time]);
    PRINT 'Created index IX_staff_schedules_date.';
END

-- ========================================
-- 5. INSERT SAMPLE DATA
-- ========================================

-- Insert sample staff data (only if table is empty)
IF NOT EXISTS (SELECT 1 FROM [dbo].[staff])
BEGIN
    PRINT 'Inserting sample staff data...';
    INSERT INTO [dbo].[staff] (
        [first_name], [last_name], [email], [phone], [position], [assigned_hall_id], [address], [status], [hire_date], [salary]
    ) VALUES 
    ('John', 'Doe', 'john.doe@flixmate.com', '+1-555-0101', 'Manager', 1, '123 Main St, City, State', 'Active', '2023-01-15', 50000.00),
    ('Jane', 'Smith', 'jane.smith@flixmate.com', '+1-555-0102', 'Ticket Seller', 1, '456 Oak Ave, City, State', 'Active', '2023-02-01', 35000.00),
    ('Mike', 'Johnson', 'mike.johnson@flixmate.com', '+1-555-0103', 'Concession Staff', 2, '789 Pine St, City, State', 'Active', '2023-02-15', 32000.00),
    ('Sarah', 'Wilson', 'sarah.wilson@flixmate.com', '+1-555-0104', 'Usher', 2, '321 Elm St, City, State', 'Active', '2023-03-01', 30000.00),
    ('David', 'Brown', 'david.brown@flixmate.com', '+1-555-0105', 'Security', 3, '654 Maple Dr, City, State', 'Active', '2023-03-15', 40000.00);
    PRINT 'Sample staff data inserted successfully.';
END
ELSE
BEGIN
    PRINT 'Staff table already contains data. Skipping sample data insertion.';
END

-- Insert sample schedule data (only if table is empty)
IF NOT EXISTS (SELECT 1 FROM [dbo].[staff_schedules])
BEGIN
    PRINT 'Inserting sample schedule data...';
    INSERT INTO [dbo].[staff_schedules] (
        [staff_id], [staff_name], [start_time], [end_time], [hall_id], [shift_type], [status]
    ) VALUES 
    (1, 'John Doe', '2025-09-28 08:00:00', '2025-09-28 16:00:00', 1, 'Regular', 'Scheduled'),
    (2, 'Jane Smith', '2025-09-28 14:00:00', '2025-09-28 22:00:00', 1, 'Regular', 'Scheduled'),
    (3, 'Mike Johnson', '2025-09-28 10:00:00', '2025-09-28 18:00:00', 2, 'Regular', 'Scheduled'),
    (4, 'Sarah Wilson', '2025-09-28 16:00:00', '2025-09-28 24:00:00', 2, 'Regular', 'Scheduled'),
    (5, 'David Brown', '2025-09-28 20:00:00', '2025-09-29 04:00:00', 3, 'Night', 'Scheduled');
    PRINT 'Sample schedule data inserted successfully.';
END
ELSE
BEGIN
    PRINT 'Staff_schedules table already contains data. Skipping sample data insertion.';
END

-- ========================================
-- 6. CREATE VIEWS
-- ========================================

-- Create a view for staff with their schedules (drop if exists first)
IF EXISTS (SELECT * FROM sys.views WHERE name = 'staff_with_schedules')
BEGIN
    DROP VIEW [dbo].[staff_with_schedules];
    PRINT 'Dropped existing staff_with_schedules view.';
END

CREATE VIEW [dbo].[staff_with_schedules] AS
SELECT 
    s.id,
    s.first_name,
    s.last_name,
    s.email,
    s.phone,
    s.position,
    s.assigned_hall_id,
    ch.name as hall_name,
    ch.location as hall_location,
    s.status,
    s.hire_date,
    s.salary,
    COUNT(sch.schedule_id) as total_schedules,
    MAX(sch.start_time) as last_schedule
FROM [dbo].[staff] s
LEFT JOIN [dbo].[cinema_halls] ch ON s.assigned_hall_id = ch.hall_id
LEFT JOIN [dbo].[staff_schedules] sch ON s.id = sch.staff_id
GROUP BY s.id, s.first_name, s.last_name, s.email, s.phone, s.position, 
         s.assigned_hall_id, ch.name, ch.location, s.status, s.hire_date, s.salary;
PRINT 'Created staff_with_schedules view.';

-- ========================================
-- 7. VERIFICATION
-- ========================================

-- Verify tables exist and have correct structure
PRINT 'Verifying table structure...';

-- Check staff table
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[staff]') AND type in (N'U'))
    PRINT '✓ Staff table exists';
ELSE
    PRINT '✗ Staff table missing';

-- Check staff_schedules table
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[staff_schedules]') AND type in (N'U'))
    PRINT '✓ Staff_schedules table exists';
ELSE
    PRINT '✗ Staff_schedules table missing';

-- Check foreign key constraints
IF EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_staff_cinema_halls')
    PRINT '✓ Foreign key FK_staff_cinema_halls exists';
ELSE
    PRINT '✗ Foreign key FK_staff_cinema_halls missing';

IF EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_staff_schedules_staff')
    PRINT '✓ Foreign key FK_staff_schedules_staff exists';
ELSE
    PRINT '✗ Foreign key FK_staff_schedules_staff missing';

IF EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_staff_schedules_cinema_halls')
    PRINT '✓ Foreign key FK_staff_schedules_cinema_halls exists';
ELSE
    PRINT '✗ Foreign key FK_staff_schedules_cinema_halls missing';

-- Check sample data
DECLARE @staff_count INT = (SELECT COUNT(*) FROM [dbo].[staff]);
DECLARE @schedule_count INT = (SELECT COUNT(*) FROM [dbo].[staff_schedules]);

PRINT 'Sample data verification:';
PRINT 'Staff records: ' + CAST(@staff_count AS VARCHAR(10));
PRINT 'Schedule records: ' + CAST(@schedule_count AS VARCHAR(10));

PRINT '';
PRINT '========================================';
PRINT 'Staff Database Schema Setup Complete!';
PRINT '========================================';
PRINT '';
PRINT 'Tables created/updated:';
PRINT '- staff (with foreign key to cinema_halls)';
PRINT '- staff_schedules (with foreign keys to staff and cinema_halls)';
PRINT '';
PRINT 'Features added:';
PRINT '- Comprehensive staff information fields';
PRINT '- Staff scheduling with hall assignments';
PRINT '- Foreign key relationships for data integrity';
PRINT '- Performance indexes for fast queries';
PRINT '- Sample data for testing';
PRINT '';
PRINT 'The staff management system is now ready to use!';
