-- Populate bookings table with sample data
-- This script creates realistic bookings based on existing users, showtimes, and seats

-- Clear existing bookings first (if any)
DELETE FROM booking_seats;
DELETE FROM bookings;

-- Insert sample bookings
-- Booking 1: John Doe books The Matrix (showtime 1) - 2 seats
INSERT INTO bookings (booking_date, total_seats, total_amount, status, user_id, showtime_id)
VALUES ('2025-09-21T10:30:00', 2, 20.00, 'CONFIRMED', 2, 1);

-- Insert seat associations for booking 1
INSERT INTO booking_seats (booking_id, seat_id) VALUES (1, 1);  -- A1
INSERT INTO booking_seats (booking_id, seat_id) VALUES (1, 2);  -- A2

-- Update seat status to RESERVED
UPDATE seats SET status = 'RESERVED' WHERE seat_id IN (1, 2);

-- Booking 2: Jane Smith books Inception (showtime 4) - 3 seats
INSERT INTO bookings (booking_date, total_seats, total_amount, status, user_id, showtime_id)
VALUES ('2025-09-21T11:15:00', 3, 45.00, 'CONFIRMED', 3, 4);

-- Insert seat associations for booking 2
INSERT INTO booking_seats (booking_id, seat_id) VALUES (2, 11);  -- B1
INSERT INTO booking_seats (booking_id, seat_id) VALUES (2, 12);  -- B2
INSERT INTO booking_seats (booking_id, seat_id) VALUES (2, 13);  -- B3

-- Update seat status to RESERVED
UPDATE seats SET status = 'RESERVED' WHERE seat_id IN (11, 12, 13);

-- Booking 3: Mike Johnson books The Dark Knight (showtime 7) - 1 seat
INSERT INTO bookings (booking_date, total_seats, total_amount, status, user_id, showtime_id)
VALUES ('2025-09-21T12:00:00', 1, 18.00, 'CONFIRMED', 4, 7);

-- Insert seat associations for booking 3
INSERT INTO booking_seats (booking_id, seat_id) VALUES (3, 21);  -- C1

-- Update seat status to RESERVED
UPDATE seats SET status = 'RESERVED' WHERE seat_id IN (21);

-- Booking 4: Sarah Wilson books Avatar (showtime 9) - 4 seats
INSERT INTO bookings (booking_date, total_seats, total_amount, status, user_id, showtime_id)
VALUES ('2025-09-21T13:45:00', 4, 100.00, 'CONFIRMED', 5, 9);

-- Insert seat associations for booking 4
INSERT INTO booking_seats (booking_id, seat_id) VALUES (4, 31);  -- D1
INSERT INTO booking_seats (booking_id, seat_id) VALUES (4, 32);  -- D2
INSERT INTO booking_seats (booking_id, seat_id) VALUES (4, 33);  -- D3
INSERT INTO booking_seats (booking_id, seat_id) VALUES (4, 34);  -- D4

-- Update seat status to RESERVED
UPDATE seats SET status = 'RESERVED' WHERE seat_id IN (31, 32, 33, 34);

-- Booking 5: John Doe books Titanic (showtime 11) - 2 seats
INSERT INTO bookings (booking_date, total_seats, total_amount, status, user_id, showtime_id)
VALUES ('2025-09-21T14:30:00', 2, 44.00, 'CONFIRMED', 2, 11);

-- Insert seat associations for booking 5
INSERT INTO booking_seats (booking_id, seat_id) VALUES (5, 41);  -- E1
INSERT INTO booking_seats (booking_id, seat_id) VALUES (5, 42);  -- E2

-- Update seat status to RESERVED
UPDATE seats SET status = 'RESERVED' WHERE seat_id IN (41, 42);

-- Booking 6: Jane Smith books Spider-Man: No Way Home (showtime 13) - 3 seats
INSERT INTO bookings (booking_date, total_seats, total_amount, status, user_id, showtime_id)
VALUES ('2025-09-21T15:15:00', 3, 90.00, 'CONFIRMED', 3, 13);

-- Insert seat associations for booking 6
INSERT INTO booking_seats (booking_id, seat_id) VALUES (6, 51);  -- F1
INSERT INTO booking_seats (booking_id, seat_id) VALUES (6, 52);  -- F2
INSERT INTO booking_seats (booking_id, seat_id) VALUES (6, 53);  -- F3

-- Update seat status to RESERVED
UPDATE seats SET status = 'RESERVED' WHERE seat_id IN (51, 52, 53);

-- Booking 7: Mike Johnson books Dune (showtime 15) - 2 seats
INSERT INTO bookings (booking_date, total_seats, total_amount, status, user_id, showtime_id)
VALUES ('2025-09-21T16:00:00', 2, 64.00, 'CONFIRMED', 4, 15);

-- Insert seat associations for booking 7
INSERT INTO booking_seats (booking_id, seat_id) VALUES (7, 61);  -- G1
INSERT INTO booking_seats (booking_id, seat_id) VALUES (7, 62);  -- G2

-- Update seat status to RESERVED
UPDATE seats SET status = 'RESERVED' WHERE seat_id IN (61, 62);

-- Booking 8: Sarah Wilson books The Matrix (showtime 2) - 1 seat
INSERT INTO bookings (booking_date, total_seats, total_amount, status, user_id, showtime_id)
VALUES ('2025-09-21T16:45:00', 1, 12.00, 'CONFIRMED', 5, 2);

-- Insert seat associations for booking 8
INSERT INTO booking_seats (booking_id, seat_id) VALUES (8, 71);  -- H1

-- Update seat status to RESERVED
UPDATE seats SET status = 'RESERVED' WHERE seat_id IN (71);

-- Booking 9: John Doe books Inception (showtime 5) - 2 seats
INSERT INTO bookings (booking_date, total_seats, total_amount, status, user_id, showtime_id)
VALUES ('2025-09-21T17:30:00', 2, 36.00, 'CONFIRMED', 2, 5);

-- Insert seat associations for booking 9
INSERT INTO booking_seats (booking_id, seat_id) VALUES (9, 81);  -- I1
INSERT INTO booking_seats (booking_id, seat_id) VALUES (9, 82);  -- I2

-- Update seat status to RESERVED
UPDATE seats SET status = 'RESERVED' WHERE seat_id IN (81, 82);

-- Booking 10: Jane Smith books The Dark Knight (showtime 8) - 3 seats
INSERT INTO bookings (booking_date, total_seats, total_amount, status, user_id, showtime_id)
VALUES ('2025-09-21T18:15:00', 3, 60.00, 'CONFIRMED', 3, 8);

-- Insert seat associations for booking 10
INSERT INTO booking_seats (booking_id, seat_id) VALUES (10, 91);  -- J1
INSERT INTO booking_seats (booking_id, seat_id) VALUES (10, 92);  -- J2
INSERT INTO booking_seats (booking_id, seat_id) VALUES (10, 93);  -- J3

-- Update seat status to RESERVED
UPDATE seats SET status = 'RESERVED' WHERE seat_id IN (91, 92, 93);

-- Booking 11: Mike Johnson books Avatar (showtime 10) - 1 seat
INSERT INTO bookings (booking_date, total_seats, total_amount, status, user_id, showtime_id)
VALUES ('2025-09-21T19:00:00', 1, 28.00, 'CONFIRMED', 4, 10);

-- Insert seat associations for booking 11
INSERT INTO booking_seats (booking_id, seat_id) VALUES (11, 101);  -- K1 (if exists) or use next available

-- Update seat status to RESERVED
UPDATE seats SET status = 'RESERVED' WHERE seat_id IN (101);

-- Booking 12: Sarah Wilson books Titanic (showtime 12) - 2 seats
INSERT INTO bookings (booking_date, total_seats, total_amount, status, user_id, showtime_id)
VALUES ('2025-09-21T19:45:00', 2, 50.00, 'CONFIRMED', 5, 12);

-- Insert seat associations for booking 12
INSERT INTO booking_seats (booking_id, seat_id) VALUES (12, 111);  -- L1 (if exists) or use next available
INSERT INTO booking_seats (booking_id, seat_id) VALUES (12, 112);  -- L2 (if exists) or use next available

-- Update seat status to RESERVED
UPDATE seats SET status = 'RESERVED' WHERE seat_id IN (111, 112);

-- Booking 13: John Doe books Spider-Man: No Way Home (showtime 14) - 2 seats
INSERT INTO bookings (booking_date, total_seats, total_amount, status, user_id, showtime_id)
VALUES ('2025-09-21T20:30:00', 2, 70.00, 'CONFIRMED', 2, 14);

-- Insert seat associations for booking 13
INSERT INTO booking_seats (booking_id, seat_id) VALUES (13, 121);  -- M1 (if exists) or use next available
INSERT INTO booking_seats (booking_id, seat_id) VALUES (13, 122);  -- M2 (if exists) or use next available

-- Update seat status to RESERVED
UPDATE seats SET status = 'RESERVED' WHERE seat_id IN (121, 122);

-- Booking 14: Jane Smith books Dune (showtime 16) - 1 seat
INSERT INTO bookings (booking_date, total_seats, total_amount, status, user_id, showtime_id)
VALUES ('2025-09-21T21:15:00', 1, 28.00, 'CONFIRMED', 3, 16);

-- Insert seat associations for booking 14
INSERT INTO booking_seats (booking_id, seat_id) VALUES (14, 131);  -- N1 (if exists) or use next available

-- Update seat status to RESERVED
UPDATE seats SET status = 'RESERVED' WHERE seat_id IN (131);

-- Booking 15: Mike Johnson books The Matrix (showtime 3) - 3 seats
INSERT INTO bookings (booking_date, total_seats, total_amount, status, user_id, showtime_id)
VALUES ('2025-09-21T22:00:00', 3, 45.00, 'CONFIRMED', 4, 3);

-- Insert seat associations for booking 15
INSERT INTO booking_seats (booking_id, seat_id) VALUES (15, 141);  -- O1 (if exists) or use next available
INSERT INTO booking_seats (booking_id, seat_id) VALUES (15, 142);  -- O2 (if exists) or use next available
INSERT INTO booking_seats (booking_id, seat_id) VALUES (15, 143);  -- O3 (if exists) or use next available

-- Update seat status to RESERVED
UPDATE seats SET status = 'RESERVED' WHERE seat_id IN (141, 142, 143);

-- Add some cancelled bookings for variety
-- Booking 16: Sarah Wilson books Inception (showtime 6) - 2 seats (CANCELLED)
INSERT INTO bookings (booking_date, total_seats, total_amount, status, user_id, showtime_id)
VALUES ('2025-09-21T23:00:00', 2, 40.00, 'CANCELLED', 5, 6);

-- Insert seat associations for booking 16
INSERT INTO booking_seats (booking_id, seat_id) VALUES (16, 151);  -- P1 (if exists) or use next available
INSERT INTO booking_seats (booking_id, seat_id) VALUES (16, 152);  -- P2 (if exists) or use next available

-- Update seat status back to AVAILABLE for cancelled booking
UPDATE seats SET status = 'AVAILABLE' WHERE seat_id IN (151, 152);

-- Booking 17: John Doe books The Dark Knight (showtime 7) - 1 seat (CANCELLED)
INSERT INTO bookings (booking_date, total_seats, total_amount, status, user_id, showtime_id)
VALUES ('2025-09-21T23:30:00', 1, 18.00, 'CANCELLED', 2, 7);

-- Insert seat associations for booking 17
INSERT INTO booking_seats (booking_id, seat_id) VALUES (17, 161);  -- Q1 (if exists) or use next available

-- Update seat status back to AVAILABLE for cancelled booking
UPDATE seats SET status = 'AVAILABLE' WHERE seat_id IN (161);

PRINT 'Bookings table populated successfully with 17 sample bookings';
