-- Fix Schedule Timestamps
-- This script fixes the timestamp conversion issues in staff_schedules table

USE FLIXMATE_2_0;
GO

-- Check current data in staff_schedules table
SELECT * FROM staff_schedules;

-- Update any invalid timestamp data
-- First, let's see what the current data looks like
SELECT 
    schedule_id,
    staff_name,
    start_time,
    end_time,
    hall_id,
    created_at,
    updated_at
FROM staff_schedules;

-- If there are any NULL or invalid timestamps, update them
UPDATE staff_schedules 
SET start_time = GETDATE(),
    end_time = DATEADD(hour, 4, GETDATE()),
    created_at = GETDATE(),
    updated_at = GETDATE()
WHERE start_time IS NULL OR end_time IS NULL;

-- Insert some sample schedule data with proper timestamps
IF NOT EXISTS (SELECT 1 FROM staff_schedules WHERE staff_name = 'John Doe')
BEGIN
    INSERT INTO staff_schedules (
        staff_id, staff_name, start_time, end_time, hall_id, 
        shift_type, status, notes, created_at, updated_at
    ) VALUES
    (1, 'John Doe', '2024-09-28 09:00:00', '2024-09-28 17:00:00', 1, 'Regular', 'Scheduled', 'Morning shift', GETDATE(), GETDATE()),
    (2, 'Jane Smith', '2024-09-28 10:00:00', '2024-09-28 18:00:00', 2, 'Regular', 'Scheduled', 'Ticket sales', GETDATE(), GETDATE()),
    (3, 'Mike Johnson', '2024-09-28 14:00:00', '2024-09-28 22:00:00', 3, 'Regular', 'Scheduled', 'Evening shift', GETDATE(), GETDATE()),
    (1, 'John Doe', '2024-09-29 09:00:00', '2024-09-29 17:00:00', 1, 'Regular', 'Scheduled', 'Morning shift', GETDATE(), GETDATE()),
    (2, 'Jane Smith', '2024-09-29 10:00:00', '2024-09-29 18:00:00', 2, 'Regular', 'Scheduled', 'Ticket sales', GETDATE(), GETDATE()),
    (3, 'Mike Johnson', '2024-09-29 14:00:00', '2024-09-29 22:00:00', 3, 'Regular', 'Scheduled', 'Evening shift', GETDATE(), GETDATE()),
    (5, 'David Brown', '2024-09-30 08:00:00', '2024-09-30 16:00:00', 1, 'Regular', 'Scheduled', 'Security shift', GETDATE(), GETDATE());
    
    PRINT 'Sample schedule data inserted successfully.';
END

-- Verify the data
SELECT 
    schedule_id,
    staff_name,
    start_time,
    end_time,
    hall_id,
    shift_type,
    status
FROM staff_schedules
ORDER BY start_time;

PRINT 'Schedule timestamps fixed successfully!';
