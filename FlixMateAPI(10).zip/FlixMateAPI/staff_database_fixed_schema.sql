-- Fixed Staff Database Schema
-- This script handles both new installations and updates to existing databases
-- Aligns with existing cinema_halls table structure

PRINT 'Starting Staff Database Schema Setup...';

-- ========================================
-- 1. CREATE CINEMA_HALLS TABLE (if needed)
-- ========================================

-- Check if cinema_halls table exists, if not create it
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[cinema_halls]') AND type in (N'U'))
BEGIN
    PRINT 'Creating cinema_halls table...';
    CREATE TABLE [dbo].[cinema_halls] (
        [hall_id] INT IDENTITY(1,1) PRIMARY KEY,
        [hall_name] NVARCHAR(100) NOT NULL,
        [capacity] INT NOT NULL,
        [location] NVARCHAR(200),
        [created_at] DATETIME2 DEFAULT GETDATE(),
        [updated_at] DATETIME2 DEFAULT GETDATE()
    );
    
    -- Insert sample cinema halls
    INSERT INTO [dbo].[cinema_halls] ([hall_name], [capacity], [location]) VALUES
    ('Hall A (Ground Floor)', 150, 'Ground Floor'),
    ('Hall B (Ground Floor)', 120, 'Ground Floor'),
    ('Hall C (First Floor)', 100, 'First Floor'),
    ('Hall D (First Floor)', 80, 'First Floor');
    
    PRINT 'Cinema_halls table created successfully with sample data.';
END
ELSE
BEGIN
    PRINT 'Cinema_halls table already exists.';
END

-- ========================================
-- 2. CREATE/UPDATE STAFF TABLE
-- ========================================

-- Check if staff table exists, if not create it
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[staff]') AND type in (N'U'))
BEGIN
    PRINT 'Creating staff table...';
    CREATE TABLE [dbo].[staff] (
        [id] BIGINT IDENTITY(1,1) PRIMARY KEY,
        [first_name] NVARCHAR(50) NOT NULL,
        [last_name] NVARCHAR(50) NOT NULL,
        [email] NVARCHAR(100) NOT NULL UNIQUE,
        [phone] NVARCHAR(20),
        [position] NVARCHAR(50) NOT NULL,
        [assigned_hall_id] INT,
        [address] NVARCHAR(500),
        [status] NVARCHAR(20) NOT NULL DEFAULT 'Active',
        [hire_date] DATETIME2 DEFAULT GETDATE(),
        [salary] DECIMAL(10,2),
        [emergency_contact_name] NVARCHAR(100),
        [emergency_contact_phone] NVARCHAR(20),
        [date_of_birth] DATE,
        [national_id] NVARCHAR(20),
        [created_at] DATETIME2 DEFAULT GETDATE(),
        [updated_at] DATETIME2 DEFAULT GETDATE()
    );
    PRINT 'Staff table created successfully.';
END
ELSE
BEGIN
    PRINT 'Staff table already exists. Checking for missing columns...';
    
    -- Add new columns to existing staff table if they don't exist
    IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID('staff') AND name = 'assigned_hall_id')
    BEGIN
        ALTER TABLE [dbo].[staff] ADD [assigned_hall_id] INT;
        PRINT 'Added assigned_hall_id column.';
    END
    
    IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID('staff') AND name = 'salary')
    BEGIN
        ALTER TABLE [dbo].[staff] ADD [salary] DECIMAL(10,2);
        PRINT 'Added salary column.';
    END
    
    IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID('staff') AND name = 'emergency_contact_name')
    BEGIN
        ALTER TABLE [dbo].[staff] ADD [emergency_contact_name] NVARCHAR(100);
        PRINT 'Added emergency_contact_name column.';
    END
    
    IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID('staff') AND name = 'emergency_contact_phone')
    BEGIN
        ALTER TABLE [dbo].[staff] ADD [emergency_contact_phone] NVARCHAR(20);
        PRINT 'Added emergency_contact_phone column.';
    END
    
    IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID('staff') AND name = 'date_of_birth')
    BEGIN
        ALTER TABLE [dbo].[staff] ADD [date_of_birth] DATE;
        PRINT 'Added date_of_birth column.';
    END
    
    IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID('staff') AND name = 'national_id')
    BEGIN
        ALTER TABLE [dbo].[staff] ADD [national_id] NVARCHAR(20);
        PRINT 'Added national_id column.';
    END
    
    IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID('staff') AND name = 'created_at')
    BEGIN
        ALTER TABLE [dbo].[staff] ADD [created_at] DATETIME2 DEFAULT GETDATE();
        PRINT 'Added created_at column.';
    END
    
    IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID('staff') AND name = 'updated_at')
    BEGIN
        ALTER TABLE [dbo].[staff] ADD [updated_at] DATETIME2 DEFAULT GETDATE();
        PRINT 'Added updated_at column.';
    END
END

-- ========================================
-- 3. CREATE/UPDATE STAFF_SCHEDULES TABLE
-- ========================================

-- Check if staff_schedules table exists, if not create it
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[staff_schedules]') AND type in (N'U'))
BEGIN
    PRINT 'Creating staff_schedules table...';
    CREATE TABLE [dbo].[staff_schedules] (
        [schedule_id] BIGINT IDENTITY(1,1) PRIMARY KEY,
        [staff_id] BIGINT NOT NULL,
        [staff_name] NVARCHAR(100) NOT NULL,
        [start_time] DATETIME2 NOT NULL,
        [end_time] DATETIME2 NOT NULL,
        [hall_id] INT NOT NULL,
        [shift_type] NVARCHAR(20) DEFAULT 'Regular',
        [status] NVARCHAR(20) DEFAULT 'Scheduled',
        [notes] NVARCHAR(500),
        [created_at] DATETIME2 DEFAULT GETDATE(),
        [updated_at] DATETIME2 DEFAULT GETDATE()
    );
    PRINT 'Staff_schedules table created successfully.';
END
ELSE
BEGIN
    PRINT 'Staff_schedules table already exists. Checking for missing columns...';
    
    -- Add new columns to existing staff_schedules table if they don't exist
    IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID('staff_schedules') AND name = 'staff_id')
    BEGIN
        ALTER TABLE [dbo].[staff_schedules] ADD [staff_id] BIGINT;
        PRINT 'Added staff_id column.';
    END
    
    IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID('staff_schedules') AND name = 'shift_type')
    BEGIN
        ALTER TABLE [dbo].[staff_schedules] ADD [shift_type] NVARCHAR(20) DEFAULT 'Regular';
        PRINT 'Added shift_type column.';
    END
    
    IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID('staff_schedules') AND name = 'status')
    BEGIN
        ALTER TABLE [dbo].[staff_schedules] ADD [status] NVARCHAR(20) DEFAULT 'Scheduled';
        PRINT 'Added status column.';
    END
    
    IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID('staff_schedules') AND name = 'notes')
    BEGIN
        ALTER TABLE [dbo].[staff_schedules] ADD [notes] NVARCHAR(500);
        PRINT 'Added notes column.';
    END
    
    IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID('staff_schedules') AND name = 'created_at')
    BEGIN
        ALTER TABLE [dbo].[staff_schedules] ADD [created_at] DATETIME2 DEFAULT GETDATE();
        PRINT 'Added created_at column.';
    END
    
    IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID('staff_schedules') AND name = 'updated_at')
    BEGIN
        ALTER TABLE [dbo].[staff_schedules] ADD [updated_at] DATETIME2 DEFAULT GETDATE();
        PRINT 'Added updated_at column.';
    END
END

-- ========================================
-- 4. ADD FOREIGN KEY CONSTRAINTS (SAFELY)
-- ========================================

-- Add foreign key constraint for staff.assigned_hall_id if it doesn't exist
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_staff_cinema_halls')
BEGIN
    BEGIN TRY
        ALTER TABLE [dbo].[staff] ADD CONSTRAINT FK_staff_cinema_halls 
        FOREIGN KEY ([assigned_hall_id]) REFERENCES [dbo].[cinema_halls]([hall_id]);
        PRINT 'Added foreign key constraint FK_staff_cinema_halls.';
    END TRY
    BEGIN CATCH
        PRINT 'Warning: Could not add foreign key constraint FK_staff_cinema_halls. Some data may not be valid.';
    END CATCH
END

-- Add foreign key constraint for staff_schedules.staff_id if it doesn't exist
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_staff_schedules_staff')
BEGIN
    BEGIN TRY
        ALTER TABLE [dbo].[staff_schedules] ADD CONSTRAINT FK_staff_schedules_staff 
        FOREIGN KEY ([staff_id]) REFERENCES [dbo].[staff]([id]) ON DELETE CASCADE;
        PRINT 'Added foreign key constraint FK_staff_schedules_staff.';
    END TRY
    BEGIN CATCH
        PRINT 'Warning: Could not add foreign key constraint FK_staff_schedules_staff. Some data may not be valid.';
    END CATCH
END

-- Add foreign key constraint for staff_schedules.hall_id if it doesn't exist
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_staff_schedules_cinema_halls')
BEGIN
    BEGIN TRY
        ALTER TABLE [dbo].[staff_schedules] ADD CONSTRAINT FK_staff_schedules_cinema_halls 
        FOREIGN KEY ([hall_id]) REFERENCES [dbo].[cinema_halls]([hall_id]);
        PRINT 'Added foreign key constraint FK_staff_schedules_cinema_halls.';
    END TRY
    BEGIN CATCH
        PRINT 'Warning: Could not add foreign key constraint FK_staff_schedules_cinema_halls. Some data may not be valid.';
    END CATCH
END

-- ========================================
-- 5. INSERT SAMPLE DATA
-- ========================================

-- Insert sample staff members if table is empty
IF NOT EXISTS (SELECT 1 FROM [dbo].[staff])
BEGIN
    PRINT 'Inserting sample staff data...';
    
    INSERT INTO [dbo].[staff] ([first_name], [last_name], [email], [phone], [position], [assigned_hall_id], [address], [status], [salary], [emergency_contact_name], [emergency_contact_phone], [date_of_birth], [national_id]) VALUES
    ('John', 'Doe', 'john.doe@flixmate.com', '+1-555-0101', 'Manager', 1, '123 Main St, City', 'Active', 5000.00, 'Jane Doe', '+1-555-0102', '1985-03-15', 'ID123456789'),
    ('Jane', 'Smith', 'jane.smith@flixmate.com', '+1-555-0201', 'Usher', 1, '456 Oak Ave, City', 'Active', 2500.00, 'Bob Smith', '+1-555-0202', '1990-07-22', 'ID987654321'),
    ('Mike', 'Johnson', 'mike.johnson@flixmate.com', '+1-555-0301', 'Ticket Seller', 2, '789 Pine St, City', 'Active', 2200.00, 'Sarah Johnson', '+1-555-0302', '1988-11-08', 'ID456789123'),
    ('Sarah', 'Wilson', 'sarah.wilson@flixmate.com', '+1-555-0401', 'Concession Worker', 2, '321 Elm St, City', 'Active', 2000.00, 'Tom Wilson', '+1-555-0402', '1992-05-14', 'ID789123456'),
    ('David', 'Brown', 'david.brown@flixmate.com', '+1-555-0501', 'Cleaner', 3, '654 Maple Dr, City', 'Active', 1800.00, 'Lisa Brown', '+1-555-0502', '1987-09-30', 'ID321654987');
    
    PRINT 'Sample staff data inserted successfully.';
END
ELSE
BEGIN
    PRINT 'Staff table already contains data. Skipping sample data insertion.';
END

-- Insert sample staff schedules if table is empty
IF NOT EXISTS (SELECT 1 FROM [dbo].[staff_schedules])
BEGIN
    PRINT 'Inserting sample schedule data...';
    
    INSERT INTO [dbo].[staff_schedules] ([staff_id], [staff_name], [start_time], [end_time], [hall_id], [shift_type], [status], [notes]) VALUES
    (1, 'John Doe', '2025-01-28 09:00:00', '2025-01-28 17:00:00', 1, 'Day', 'Scheduled', 'Manager shift'),
    (2, 'Jane Smith', '2025-01-28 10:00:00', '2025-01-28 18:00:00', 1, 'Day', 'Scheduled', 'Usher shift'),
    (3, 'Mike Johnson', '2025-01-28 11:00:00', '2025-01-28 19:00:00', 2, 'Day', 'Scheduled', 'Ticket sales'),
    (4, 'Sarah Wilson', '2025-01-28 12:00:00', '2025-01-28 20:00:00', 2, 'Day', 'Scheduled', 'Concession'),
    (5, 'David Brown', '2025-01-28 08:00:00', '2025-01-28 16:00:00', 3, 'Day', 'Scheduled', 'Cleaning shift');
    
    PRINT 'Sample schedule data inserted successfully.';
END
ELSE
BEGIN
    PRINT 'Staff_schedules table already contains data. Skipping sample data insertion.';
END

-- ========================================
-- 6. CREATE INDEXES FOR PERFORMANCE
-- ========================================

-- Create index on staff.email for faster lookups
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_staff_email')
BEGIN
    CREATE INDEX IX_staff_email ON [dbo].[staff] ([email]);
    PRINT 'Created index IX_staff_email.';
END

-- Create index on staff.assigned_hall_id for faster lookups
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_staff_assigned_hall_id')
BEGIN
    CREATE INDEX IX_staff_assigned_hall_id ON [dbo].[staff] ([assigned_hall_id]);
    PRINT 'Created index IX_staff_assigned_hall_id.';
END

-- Create index on staff_schedules.staff_id for faster lookups
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_staff_schedules_staff_id')
BEGIN
    CREATE INDEX IX_staff_schedules_staff_id ON [dbo].[staff_schedules] ([staff_id]);
    PRINT 'Created index IX_staff_schedules_staff_id.';
END

-- Create index on staff_schedules.hall_id for faster lookups
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_staff_schedules_hall_id')
BEGIN
    CREATE INDEX IX_staff_schedules_hall_id ON [dbo].[staff_schedules] ([hall_id]);
    PRINT 'Created index IX_staff_schedules_hall_id.';
END

-- Create index on staff_schedules.start_time for faster date queries
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_staff_schedules_start_time')
BEGIN
    CREATE INDEX IX_staff_schedules_start_time ON [dbo].[staff_schedules] ([start_time]);
    PRINT 'Created index IX_staff_schedules_start_time.';
END

PRINT 'Staff Database Schema Setup Completed Successfully!';
PRINT 'Tables created/updated: cinema_halls, staff, staff_schedules';
PRINT 'Foreign key constraints added with error handling';
PRINT 'Sample data inserted (if tables were empty)';
PRINT 'Performance indexes created';
